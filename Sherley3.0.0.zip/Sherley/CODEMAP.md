# Sherley code map (where to add your own code)

All app code lives in `app/src/main/java/com/sherley/app/`. The 3D engine is the `corelib/` module
(AIAvatar-SDK source). Add your code to the app, not to corelib, unless you need a new engine feature.

## How the pieces connect
You type -> ui/MainScreen -> ui/ChatViewModel.send()
  1. "open <app>"            -> reflex/AppLauncher
  2. body commands           -> ChatViewModel.parseAction() -> UiState.action -> avatar/AvatarScene -> avatar/Room (walk, sit) or AvatarBody.play (gestures)
  3. everything else         -> ai/LocalLlmClient (Thinai at 127.0.0.1:11434) -> reply + events
Events -> companion/MoodEngine -> mood + needs -> avatar/FaceMap -> avatar/AvatarDriver (30 Hz) -> AvatarBody -> face on screen.
Touch -> avatar/TouchLayer -> ChatViewModel.touch() -> avatar/Reactions -> face flash + gesture + mood change.

## Folders
| Folder | What it does | Add here |
|---|---|---|
| ai/ | Talks to the local model (Http.kt timeouts, LocalLlmClient.kt prompts/parsing) | A new AI backend, tools, streaming |
| companion/ | Her personality: Mood.kt (43 moods), Needs.kt, MoodEngine.kt (scores), ChatEvent.kt (what chat events do), Persona.kt (system prompt) | New moods, new chat events, personality tuning |
| avatar/ | Everything 3D: AvatarBody (wrapper over the engine), AvatarScene (the view, loads model/room, camera, actions), Room (walking, sitting), AvatarDriver (blink, face, mouth), FaceMap, Reactions, TouchLayer, BodyLayout/Pose/PoseController/JointCalibration | New touch reactions (Reactions.kt), new faces (FaceMap.kt), new room spots (Room.kt) |
| ui/ | Screens: MainScreen (main layer stack + menu), SettingsScreen, AppDrawerScreen, ChatViewModel (the brain of the UI), SherleyApp (navigation) | New screens, buttons, settings rows |
| config/ | AppConfig.kt (constants), AppSettings.kt (saved settings), CrashInfo.kt | New saved setting = one property in AppSettings |
| data/ memory/ | Room database for chat history, summaries of old chats | New stored data, smarter memory |
| reflex/ | Instant replies and "open app" | New instant commands |

## Recipes
- **New saved setting**: add a property to config/AppSettings.kt, add a row in ui/SettingsScreen.kt, read it in ui/MainScreen.kt and pass it to where it is used.
- **New body command** ("dance"): add a regex line in ChatViewModel.parseAction(), a reply in doAction(), and play it in the `else` branch of AvatarScene's action effect (body.play("dance", false)). Put the animation in assets/vrmas/dance.vrma.
- **New animation**: any VRMA file in assets/vrmas/ (generated ones come from a Python script; Mixamo-converted ones are in assets/animations/).
- **New touch reaction**: add an entry to the list in avatar/Reactions.kt (zone + kind + face + gesture + mood push). Zones are limited to head, neck, shoulders, arms, hands.
- **New mood**: Mood.kt (enum), MoodEngine.baseScore (when it wins), FaceMap.kt (its face), plus the colour in ui/MoodBackground.kt.
- **New chat event the AI can tag**: ChatEvent.kt (needs + mood boosts), then it is offered to the model automatically.
- **New room**: put NAME.glb + NAME.meta.json + NAME.anchors.json + NAME.interactions.json in assets/scene/, add NAME to the room lists in ui/MainScreen.kt and ui/SettingsScreen.kt.
- **New AI call**: add a function in ai/LocalLlmClient.kt and call it from ChatViewModel.
- **Engine feature** (new effect, prop): look at corelib/src/main/java/com/neethu/corelib/AvatarController.kt (the public API list) and call it through avatar/AvatarBody.kt.

## Rules that save you build errors
- Everything the engine can do is in corelib's AvatarController. Check a function exists there before calling it.
- Keep long work off the main thread (use viewModelScope.launch in ChatViewModel).
- Android Studio is not needed: edit the files, zip, upload, run your Extract zip / Build APK workflow.

## Added later: voice, header, camera gestures, import
- `voice/Voice.kt` – Android TextToSpeech wrapper (offline English voices). Settings > Voice. The text bubble hides while voice works, unless "keep text bubble" is on.
- Header (`ui/MainScreen.kt`, `TopBar`): left button = apps launcher, right button = menu for everything else.
- Camera: one finger rotates her, two fingers pinch-zoom/pan the camera (`avatar/TouchLayer.kt`); camera modes in the right menu.
- Import (`imports/`): `Archives.kt` (.unitypackage/.zip), `ObjToGlb.kt`, `Glb.kt`, `RoomFit.kt` (guess scale/floor/bounds), `Importer.kt`, screen `ui/ImportScreen.kt`. Imported rooms live in `filesDir/rooms/user_*.glb/.meta.json`; `RoomDirector.wander()` lets her walk in them. FBX is not supported.

# Sherley

A fully offline virtual companion for Android: **Sherlock Holmes as a witty 12-year-old detective**, rendered as a 3D VRM model on your home screen. Kotlin + Jetpack Compose. No internet, no web search, no cloud.

## How it works
- **Chat:** the Thinai app runs a local language model and serves it at `http://127.0.0.1:11434`. Start Thinai's server, pick a model, keep Thinai running.
- **Mood:** 43 moods driven by 6 needs (energy, stimulation, company, respect, comfort, confidence). The model only tags what happened in your message; the app computes the mood itself (`companion/MoodEngine.kt`).
- **Body:** the VRM is drawn full screen (`avatar/AvatarScene.kt`). Her face follows her mood (`avatar/FaceMap.kt`), she blinks and moves her mouth while talking (`avatar/AvatarDriver.kt`).
- **Commands:** type `open <app name>` to launch an app (no model needed).
- **Touch:** she reacts on her head, neck, shoulders, arms and hands (nothing on the torso or legs). Tap, double-tap, stroke, or tap repeatedly: 36 reactions in `avatar/Reactions.kt`, each with a face, an arm/head gesture, a line, and a mood effect. Some depend on her mood (a head pat feels different when she is sad, annoyed or sleepy). Add your own at the bottom of that file.
- **Camera:** the 🎥 button toggles camera mode. Drag = rotate around her, pinch = zoom, two-finger drag = move up/down. The side buttons do the same. Touch reactions pause while it is on.
- **Posing:** long-press a joint (neck, shoulders, elbows) and drag anywhere to aim it. A bar appears: Save pose / Discard / Natural. A saved pose is kept between launches; ⋮ > Reset pose returns her to natural. (The library can only pose the head and arms, not wrists, fingers or legs.)
- **Widgets:** the speech bubble and the text box are draggable (drag the dots, double-tap to reset). The ◐ button hides all widgets. ▦ opens an app list; the app also registers as a home-screen launcher.

## Setup
1. Put a `.vrm` file in `app/src/main/assets/vrms/` (GitHub's web upload limit is 25 MB per file), **or** install the app and use Settings > Pick a .vrm model file.
2. In your `build-apk.yml`, set `gradle-version: 8.13` (the app needs Android Gradle Plugin 8.13).
3. Upload `Sherley.zip`; the extract workflow unpacks it and Build APK runs.
4. Settings > Test Thinai connection.
5. Settings > Calibrate joints: drag each yellow dot onto the matching joint on her body and Save. This makes touch and posing accurate for your model. Settings > Developer overlay shows the joint dots.
6. If her face looks distorted, lower Settings > Face expression strength (0 keeps the model's own face).

## If the avatar misbehaves
The 3D library (`io.github.hufeiya:corelib:0.1.5`) is young and its methods are called by name through reflection (`avatar/ReflectiveCall.kt`), so a wrong guess fails quietly instead of crashing.
Turn on **Settings > Developer overlay**: it shows the model state, every method the controller really has, and buttons that test each expression. Send me that list if faces or loading do not work.
If you cannot see the mood background, that is expected: the avatar surface covers it. The toggle "Draw mood background behind her" tries to show it anyway.

## Project map (app/src/main/java/com/sherley/app)
- `ai/` talking to Thinai (`LocalLlmClient`, `Http` with 8-minute timeouts)
- `companion/` moods, needs, events, persona prompt
- `avatar/` VRM loading, face, touch zones
- `reflex/` instant pre-written reactions
- `memory/`, `data/` conversation history, facts, summary (Room database)
- `ui/` screens; `config/` all tunable numbers (`AppConfig.kt`) and saved settings

## Limits you should know
- Written without being compiled on a real build; the first Actions run may show errors. Send them to me.
- Touch is limited to head, neck, shoulders and arms, and her persona is friendly and never sexual.

## Look, 3D bedroom and actions
- The avatar library is bundled as the `:corelib` module (source from the AIAvatar-SDK repository, Apache-2.0) because the published 0.1.5 release has no 3D rooms, walking or sitting.
- Settings > Look: Anime (MToon, default), Soft (natural colours) or Realistic; quality low..ultra; light brightness.
- 3D bedroom (assets/scene/dream_bedroom.*): she walks along the room's walkway graph and can sit on the bed, the desk chair, the reading chair or the rug, and lie on the bed. Switch it off in Settings.
- Commands (chat) or the menu: "sit on the bed", "lie on the bed", "sit at the desk", "sit in the reading chair", "sit on the rug", "go to the window", "go to the TV", "walk around", "stand up", "wave", "stretch", "look around", "cheer". She also wanders and sits on her own when you are quiet.
- Room, walk and sitting animations come from Mixamo (via the SDK's converted VRMA files in assets/animations); the extra gestures are generated in assets/vrmas.

package com.sherley.app.avatar

import com.neethu.corelib.AvatarController
import com.neethu.corelib.AvatarState
import java.io.File

/** Camera axes in world space: where screen-right, screen-up and "toward the viewer" point. */
class CameraBasis(val right: FloatArray, val up: FloatArray, val toViewer: FloatArray)

/**
 * Sherley's body: the small set of things the app asks the 3D model to do.
 * A thin, typed wrapper over the library's AvatarController.
 */
class AvatarBody(val controller: AvatarController) {

    /** Name variants models use for the same expression. The first one the model really has wins. */
    private val candidates = mapOf(
        "joy" to listOf("joy", "happy"),
        "angry" to listOf("angry"),
        "sad" to listOf("sorrow", "sad"),
        "relaxed" to listOf("relaxed", "fun"),
        "surprised" to listOf("surprised"),
        "blink" to listOf("blink"),
        "aa" to listOf("aa", "a"),
    )
    private var resolved: Map<String, String?>? = null

    /** Call after a model load so expression names are looked up again. */
    fun invalidate() { resolved = null; blinkNames = null; lastBlink = -1f }

    fun expressionNames(): List<String> = controller.getAvailableExpressions()

    private fun resolve(preset: String): String? {
        var map = resolved
        if (map == null) {
            val avail = controller.getAvailableExpressions()
            if (avail.isEmpty()) return null
            val byLower = avail.associateBy { it.lowercase() }
            map = candidates.mapValues { (_, names) -> names.firstNotNullOfOrNull { byLower[it] } }
            resolved = map
        }
        return map[preset]
    }

    fun setExpression(preset: String, value: Float) {
        val name = resolve(preset) ?: return
        controller.setExpression(name, value.coerceIn(0f, 1f))
    }

    private var blinkNames: List<String>? = null
    private var lastBlink = -1f

    /** Every eye-closing expression the model has (one "blink", or separate left/right ones). */
    private fun blinkTargets(): List<String> {
        blinkNames?.let { return it }
        val avail = controller.getAvailableExpressions()
        if (avail.isEmpty()) return emptyList()
        val exact = avail.firstOrNull { it.equals("blink", ignoreCase = true) }
        val list = if (exact != null) listOf(exact) else avail.filter {
            val l = it.lowercase()
            (l.contains("blink") || l == "close" || l.contains("eyesclosed") || l.contains("eyeclose")) && !l.contains("look")
        }
        blinkNames = list
        return list
    }

    /** Closes the eyes by [v] (0 open .. 1 closed). Only sent when it changes, so it never fights other expression drivers. */
    fun setBlink(v: Float) {
        val value = v.coerceIn(0f, 1f)
        if (kotlin.math.abs(value - lastBlink) < 0.01f) return
        lastBlink = value
        for (n in blinkTargets()) controller.setExpression(n, value)
    }

    fun applyFace(f: Face, blink: Float, mouth: Float) {
        setExpression("joy", f.joy)
        setExpression("angry", f.angry)
        setExpression("sad", f.sad)
        setExpression("relaxed", f.relaxed)
        setExpression("surprised", f.surprised)
        setBlink(maxOf(blink, f.eyesClosed))
        setExpression("aa", mouth)
    }

    // ---- Loading ------------------------------------------------------------
    fun loadAsset(path: String, force: Boolean) { invalidate(); controller.loadModel(path, force) }
    fun loadFile(file: File, force: Boolean) { invalidate(); controller.loadModelFromFile(file.absolutePath, force) }

    fun isReady() = controller.state.value is AvatarState.Ready
    fun stateText(): String = when (val s = controller.state.value) {
        is AvatarState.Idle -> "Idle"
        is AvatarState.Loading -> "Loading"
        is AvatarState.Ready -> "Ready"
        is AvatarState.Error -> "Error: ${s.message}"
    }

    /**
     * Starts the looping idle animation (arms down, gentle breathing) from assets/vrmas/idle.vrma.
     * Without an animation a VRM stands in its default T-pose.
     */
    fun playIdle(path: String = "vrmas/idle.vrma"): Boolean {
        val ok = controller.setVrmaIdleAnimation(path)
        controller.stopVrmaAnimation(0f) // "stop" returns to the idle loop when one is set
        return ok
    }

    // ---- Room and actions ------------------------------------------------------
    /** Loads and plays one of the bundled animations. Looping ones stay until [stand] is called. */
    fun play(name: String, loop: Boolean): Boolean {
        if (!controller.loadVrmaAnimation("vrmas/$name.vrma")) return false
        controller.playVrmaAnimation(loop, 1f, 0.4f)
        return true
    }

    fun durationSeconds(): Float = controller.getVrmaAnimationDuration()

    /** Back to the idle loop. */
    fun stand() = controller.stopVrmaAnimation(0.5f)

    // ---- Camera ---------------------------------------------------------------
    fun zoom(spreadPx: Float) = controller.zoomCamera(spreadPx)
    fun orbit(yawPx: Float, pitchPx: Float) = controller.orbitCamera(yawPx, pitchPx)
    fun pan(dxPx: Float, dyPx: Float) = controller.panCamera(dxPx, dyPx)
    fun resetCamera() = controller.resetCamera()

    fun cameraBasis(): CameraBasis? {
        val (eye, target, up) = controller.getCameraLookAt() ?: return null
        val f = V.norm(target[0] - eye[0], target[1] - eye[1], target[2] - eye[2])
        val right = V.cross(f, up).let { V.norm(it[0], it[1], it[2]) }
        val upv = V.cross(right, f).let { V.norm(it[0], it[1], it[2]) }
        return CameraBasis(right, upv, floatArrayOf(-f[0], -f[1], -f[2]))
    }

    /** Eyes toward a point on screen (-1..1 each axis). Only used when "eyes follow finger" is on. */
    fun lookAtScreen(x: Float, y: Float) {
        val (eye, _, _) = controller.getCameraLookAt() ?: return
        val b = cameraBasis() ?: return
        controller.setLookAtTarget(
            eye[0] + b.right[0] * x * 0.8f - b.up[0] * y * 0.8f,
            eye[1] + b.right[1] * x * 0.8f - b.up[1] * y * 0.8f,
            eye[2] + b.right[2] * x * 0.8f - b.up[2] * y * 0.8f,
        )
    }

    // ---- Where she is on screen ------------------------------------------------
    // The library release this app uses has no "head position" or "project to screen" call, so both
    // are worked out here. The renderer scales every model to a 2-unit-tall cube standing on the feet.

    fun feetWorld(): FloatArray? = FloatArray(3).takeIf { controller.avatarWorldPos(it) }

    fun headTopWorld(): FloatArray? = feetWorld()?.let { floatArrayOf(it[0], it[1] + MODEL_HEIGHT, it[2]) }

    /**
     * World point to normalized screen coordinates (0..1, top-left origin) using the camera's
     * position and its look-at, or null if the point is behind the camera.
     */
    fun project(x: Float, y: Float, z: Float, aspect: Float): FloatArray? {
        val (eye, target, up) = controller.getCameraLookAt() ?: return null
        val f = V.norm(target[0] - eye[0], target[1] - eye[1], target[2] - eye[2])
        val r = V.cross(f, up).let { V.norm(it[0], it[1], it[2]) }
        val u = V.cross(r, f)
        val dx = x - eye[0]
        val dy = y - eye[1]
        val dz = z - eye[2]
        val depth = dx * f[0] + dy * f[1] + dz * f[2]
        if (depth <= 0.01f) return null
        val ndcX = (dx * r[0] + dy * r[1] + dz * r[2]) / (depth * HALF_FOV_TAN * aspect)
        val ndcY = (dx * u[0] + dy * u[1] + dz * u[2]) / (depth * HALF_FOV_TAN)
        return floatArrayOf((ndcX + 1f) * 0.5f, (1f - ndcY) * 0.5f)
    }

    /** The reverse of [project]: the world point on the plane z = [planeZ] that appears at screen (u, v). */
    fun unproject(u: Float, v: Float, aspect: Float, planeZ: Float): FloatArray? {
        val (eye, target, up) = controller.getCameraLookAt() ?: return null
        val f = V.norm(target[0] - eye[0], target[1] - eye[1], target[2] - eye[2])
        val r = V.cross(f, up).let { V.norm(it[0], it[1], it[2]) }
        val c = V.cross(r, f)
        val nx = (u * 2f - 1f) * HALF_FOV_TAN * aspect
        val ny = (1f - v * 2f) * HALF_FOV_TAN
        val dx = f[0] + r[0] * nx + c[0] * ny
        val dy = f[1] + r[1] * nx + c[1] * ny
        val dz = f[2] + r[2] * nx + c[2] * ny
        if (kotlin.math.abs(dz) < 1e-4f) return null
        val t = (planeZ - eye[2]) / dz
        if (t <= 0f) return null
        return floatArrayOf(eye[0] + dx * t, eye[1] + dy * t, planeZ)
    }

    private companion object {
        /** Height of the normalized model in world units (a 2-unit cube). */
        const val MODEL_HEIGHT = 2.0f

        /** Half the vertical field of view as a tangent: a 28 mm lens on a 24 mm sensor height. */
        const val HALF_FOV_TAN = 12f / 28f
    }
}

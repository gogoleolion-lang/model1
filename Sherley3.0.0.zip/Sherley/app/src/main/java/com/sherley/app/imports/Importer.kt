package com.sherley.app.imports

import android.content.Context
import android.net.Uri
import com.sherley.app.avatar.AvatarModel
import com.sherley.app.config.AppSettings
import java.io.File

/**
 * Brings downloaded 3D files into the app:
 *  - .vrm                       -> her body
 *  - .glb                       -> a room (or her body, if it is a VRM inside)
 *  - .obj (+ .mtl, textures)    -> a room (converted)
 *  - .zip / .unitypackage       -> unpacked, then everything above that is inside
 * FBX, glTF with separate files and other formats are recognised and reported, but not loaded.
 */
object Importer {

    enum class Kind { AVATAR, ROOM }

    class Candidate(val kind: Kind, val title: String, val file: File, val size: Long)

    class Scan(val candidates: List<Candidate>, val skipped: Map<String, Int>, val workDir: File)

    private fun workRoot(context: Context) = File(context.cacheDir, "import")

    /** Reads the chosen file and finds what can be used inside. Call off the main thread. */
    fun scan(context: Context, uri: Uri, displayName: String): Scan {
        val root = workRoot(context)
        root.deleteRecursively()
        val dir = File(root, "work").apply { mkdirs() }
        val ext = displayName.substringAfterLast('.', "").lowercase()
        val skipped = HashMap<String, Int>()

        if (ext in setOf("vrm", "glb", "obj")) {
            val target = File(dir, displayName.ifBlank { "model.$ext" })
            context.contentResolver.openInputStream(uri)?.use { i -> target.outputStream().use { i.copyTo(it) } }
                ?: error("Could not open the file.")
        } else if (ext in Archives.UNSUPPORTED) {
            skipped[ext] = 1
        } else {
            val input = context.contentResolver.openInputStream(uri) ?: error("Could not open the file.")
            input.use { skipped.putAll(Archives.extract(it, dir).skipped) }
        }

        val found = ArrayList<Candidate>()
        dir.walkTopDown().filter { it.isFile }.forEach { f ->
            val rel = f.relativeTo(dir).path
            when (f.extension.lowercase()) {
                "vrm" -> found.add(Candidate(Kind.AVATAR, rel, f, f.length()))
                "glb" -> {
                    val j = Glb.readJson(f)
                    val isVrm = j != null && (j.optJSONArray("extensionsUsed")?.toString()?.contains("VRM") == true)
                    found.add(Candidate(if (isVrm) Kind.AVATAR else Kind.ROOM, rel, f, f.length()))
                }
                "obj" -> found.add(Candidate(Kind.ROOM, rel, f, f.length()))
            }
        }
        return Scan(found.sortedByDescending { it.size }, skipped, root)
    }

    fun useAsAvatar(context: Context, c: Candidate): Boolean = try {
        c.file.inputStream().use { i -> File(context.filesDir, "avatar.vrm").outputStream().use { i.copyTo(it) } }
        true
    } catch (e: Exception) {
        false
    }

    /** Fits the model and saves it as a new room. Returns a one-line description, or throws with a readable message. */
    fun useAsRoom(context: Context, settings: AppSettings, c: Candidate): String {
        val glb = if (c.file.extension.equals("obj", true)) ObjToGlb.convert(c.file) else c.file.readBytes()
        val fitted = RoomFit.fit(glb)
        val id = "user_" + System.currentTimeMillis().toString(36)
        val dir = File(context.filesDir, "rooms").apply { mkdirs() }
        File(dir, "$id.glb").writeBytes(fitted.glb)
        File(dir, "$id.meta.json").writeText(fitted.meta.toString())
        val name = c.file.nameWithoutExtension.take(24).ifBlank { "Room" }
        settings.addUserRoom(id, name)
        settings.roomScene = id
        return "Room \"$name\" added: about %.1f x %.1f m, %.1f m high. She can walk around in it; there are no bed or chair spots (those need to be set up by hand)."
            .format(fitted.widthMetres, fitted.depthMetres, fitted.heightMetres)
    }

    fun deleteRoom(context: Context, settings: AppSettings, id: String) {
        File(context.filesDir, "rooms").listFiles()?.filter { it.name.startsWith("$id.") }?.forEach { it.delete() }
        settings.removeUserRoom(id)
        if (settings.roomScene == id) settings.roomScene = "dream_bedroom"
    }

    fun cleanUp(context: Context) { workRoot(context).deleteRecursively() }
}

package com.sherley.app.imports

import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

/**
 * Unpacks the file types people download for 3D rooms and models:
 *  - .unitypackage (a gzip-compressed tar with numbered folders and a "pathname" file in each)
 *  - .zip
 * Only the useful kinds of file are kept (models, textures, material files); the rest is skipped.
 * Everything is streamed, so big downloads do not need to fit in memory.
 */
object Archives {

    val WANTED = setOf("glb", "vrm", "obj", "mtl", "png", "jpg", "jpeg")
    /** Formats we can see inside an archive but cannot load (reported to the user). */
    val UNSUPPORTED = setOf("fbx", "gltf", "dae", "blend", "prefab", "unity")

    class Result(val dir: File, val skipped: Map<String, Int>)

    private fun ext(name: String) = name.substringAfterLast('.', "").lowercase()

    /** Extracts [input] into [outDir]. Returns what was skipped (by extension, for the message). */
    fun extract(input: InputStream, outDir: File): Result {
        outDir.mkdirs()
        val buffered = java.io.BufferedInputStream(input, 1 shl 16)
        buffered.mark(4)
        val b0 = buffered.read()
        val b1 = buffered.read()
        buffered.reset()
        val skipped = HashMap<String, Int>()
        when {
            b0 == 0x1F && b1 == 0x8B -> unpackTar(GZIPInputStream(buffered, 1 shl 16), outDir, skipped)
            b0 == 'P'.code && b1 == 'K'.code -> unpackZip(buffered, outDir, skipped)
            else -> throw IOException("This is not a .zip or .unitypackage file.")
        }
        return Result(outDir, skipped)
    }

    private fun safeTarget(root: File, relative: String): File? {
        val clean = relative.replace('\\', '/').trimStart('/')
        val f = File(root, clean).canonicalFile
        return if (f.path.startsWith(root.canonicalPath + File.separator)) f else null
    }

    private fun unpackZip(input: InputStream, outDir: File, skipped: MutableMap<String, Int>) {
        ZipInputStream(input).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (e.isDirectory) continue
                val ex = ext(e.name)
                if (ex !in WANTED) {
                    if (ex in UNSUPPORTED) skipped.merge(ex, 1, Int::plus)
                    continue
                }
                val target = safeTarget(outDir, e.name) ?: continue
                target.parentFile?.mkdirs()
                target.outputStream().use { zip.copyTo(it) }
            }
        }
    }

    private fun unpackTar(input: InputStream, outDir: File, skipped: MutableMap<String, Int>) {
        val raw = File(outDir, "_raw").apply { mkdirs() }
        val paths = HashMap<String, String>() // guid -> asset path inside the Unity project
        val tar = TarReader(input)
        while (true) {
            val e = tar.next() ?: break
            val slash = e.name.indexOf('/')
            if (e.type != '0' && e.type != '\u0000' || slash <= 0) { tar.skip(); continue }
            val guid = e.name.substring(0, slash)
            when (e.name.substring(slash + 1)) {
                "pathname" -> {
                    val text = tar.readText(e.size.toInt().coerceAtMost(4096))
                    paths[guid] = text.lineSequence().firstOrNull().orEmpty().trim()
                }
                "asset" -> tar.copyTo(File(raw, guid).outputStream().buffered(), e)
                else -> tar.skip()
            }
        }
        for ((guid, path) in paths) {
            val src = File(raw, guid)
            if (!src.exists()) continue
            val ex = ext(path)
            if (ex in WANTED) {
                val target = safeTarget(outDir, path)
                if (target != null) {
                    target.parentFile?.mkdirs()
                    if (!src.renameTo(target)) { src.copyTo(target, overwrite = true); src.delete() }
                    continue
                }
            } else if (ex in UNSUPPORTED) skipped.merge(ex, 1, Int::plus)
            src.delete()
        }
        raw.deleteRecursively()
    }
}

/** A tiny reader for the tar format (enough for Unity packages: plain files, optional long names). */
internal class TarReader(private val input: InputStream) {
    class Entry(val name: String, val size: Long, val type: Char)

    private var remaining = 0L
    private var padding = 0

    private fun readFully(buf: ByteArray): Boolean {
        var off = 0
        while (off < buf.size) {
            val n = input.read(buf, off, buf.size - off)
            if (n < 0) return off != 0 && false
            off += n
        }
        return true
    }

    private fun skipBytes(count: Long) {
        var left = count
        val scratch = ByteArray(8192)
        while (left > 0) {
            val n = input.read(scratch, 0, minOf(left, scratch.size.toLong()).toInt())
            if (n < 0) return
            left -= n
        }
    }

    /** Moves to the next file entry, or returns null at the end of the archive. */
    fun next(): Entry? {
        skipBytes(remaining + padding)
        remaining = 0; padding = 0
        var longName: String? = null
        while (true) {
            val h = ByteArray(512)
            if (!readFully(h)) return null
            if (h.all { it == 0.toByte() }) return null
            var name = String(h, 0, 100, Charsets.UTF_8).trimEnd('\u0000')
            val prefix = String(h, 345, 155, Charsets.UTF_8).trimEnd('\u0000')
            if (prefix.isNotEmpty() && String(h, 257, 5, Charsets.US_ASCII) == "ustar") name = "$prefix/$name"
            val size = parseSize(h)
            val type = h[156].toInt().toChar()
            remaining = size
            padding = ((512 - size % 512) % 512).toInt()
            when (type) {
                'L' -> { longName = readText(size.toInt().coerceAtMost(8192)).trimEnd('\u0000'); skipBytes(remaining + padding); remaining = 0; padding = 0 }
                'x', 'g' -> {
                    val pax = readText(size.toInt().coerceAtMost(65536))
                    skipBytes(remaining + padding); remaining = 0; padding = 0
                    pax.lineSequence().firstOrNull { it.substringAfter(' ').startsWith("path=") }
                        ?.let { longName = it.substringAfter("path=") }
                }
                else -> return Entry(longName ?: name, size, if (type == '\u0000') '0' else type)
            }
        }
    }

    private fun parseSize(h: ByteArray): Long {
        if (h[124].toInt() and 0x80 != 0) { // base-256 encoding for very large files
            var v = 0L
            for (i in 125 until 136) v = (v shl 8) or (h[i].toLong() and 0xFF)
            return v
        }
        val s = String(h, 124, 12, Charsets.US_ASCII).trim { it == '\u0000' || it == ' ' }
        return if (s.isEmpty()) 0 else s.toLong(8)
    }

    fun skip() { /* the next call to next() skips the rest of this entry */ }

    fun readText(max: Int): String {
        val n = minOf(remaining, max.toLong()).toInt()
        val buf = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = input.read(buf, off, n - off)
            if (r < 0) break
            off += r
        }
        remaining -= off
        return String(buf, 0, off, Charsets.UTF_8)
    }

    fun copyTo(out: OutputStream, entry: Entry) {
        out.use {
            val buf = ByteArray(1 shl 16)
            while (remaining > 0) {
                val n = input.read(buf, 0, minOf(remaining, buf.size.toLong()).toInt())
                if (n < 0) throw IOException("The archive is cut off (download incomplete?).")
                it.write(buf, 0, n)
                remaining -= n
            }
        }
    }
}

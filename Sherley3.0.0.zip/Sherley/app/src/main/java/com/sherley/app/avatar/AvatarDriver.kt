package com.sherley.app.avatar

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import com.sherley.app.companion.Mood
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

/**
 * Animates her about 30 times a second: eases her face toward her mood, flashes a reaction face when
 * touched, blinks now and then, moves her mouth while she "speaks", and feeds the arm/head pose.
 */
@Composable
fun AvatarDriver(
    body: AvatarBody?,
    mood: Mood,
    intensity: Float,
    speaking: Boolean,
    flash: Face?,
    flashKey: Int,
    pose: PoseController,
    strength: Float,
) {
    val moodNow by rememberUpdatedState(mood)
    val intensityNow by rememberUpdatedState(intensity)
    val speakingNow by rememberUpdatedState(speaking)
    val flashNow by rememberUpdatedState(flash)
    val flashKeyNow by rememberUpdatedState(flashKey)
    val strengthNow by rememberUpdatedState(strength)

    LaunchedEffect(body) {
        if (body == null) return@LaunchedEffect
        var cur = Face()
        var nextBlinkAt = System.currentTimeMillis() + 1500
        var blinkStart = -1L
        var doubleBlink = false
        var lastKey = flashKeyNow
        var flashFace: Face? = null
        var flashUntil = 0L
        while (true) {
            val now = System.currentTimeMillis()
            if (flashKeyNow != lastKey) {
                lastKey = flashKeyNow
                flashFace = flashNow
                flashUntil = now + 1800
            }
            var target = FaceMap.face(moodNow, intensityNow)
            flashFace?.let { if (now < flashUntil) target = target.maxWith(it) }
            cur = ease(cur, target.gentle(strengthNow), 0.12f)

            // A natural blink: eyes shut fast (~70 ms), stay shut a moment, open a little slower (~140 ms).
            // Now and then a quick second blink follows. Sleepy moods blink slower and less often.
            if (blinkStart < 0 && now >= nextBlinkAt) {
                blinkStart = now
                if (doubleBlink) {
                    doubleBlink = false
                    nextBlinkAt = now + 3000
                } else {
                    doubleBlink = Random.nextInt(100) < 15
                    nextBlinkAt = now + if (doubleBlink) 420L else 2200L + Random.nextLong(3800)
                }
            }
            var blink = 0f
            if (blinkStart >= 0) {
                val ms = (now - blinkStart).toFloat()
                blink = when {
                    ms < 70f -> ms / 70f
                    ms < 110f -> 1f
                    ms < 250f -> 1f - (ms - 110f) / 140f
                    else -> { blinkStart = -1; 0f }
                }
                blink = blink * blink * (3f - 2f * blink)
            }
            val mouth = if (speakingNow && strengthNow > 0f) 0.15f + 0.25f * abs(sin(now / 90.0)).toFloat() else 0f

            body.applyFace(cur, blink, mouth)
            pose.frame(body, android.os.SystemClock.elapsedRealtime())
            delay(33L)
        }
    }
}

private fun ease(a: Face, b: Face, k: Float) = Face(
    a.joy + (b.joy - a.joy) * k,
    a.angry + (b.angry - a.angry) * k,
    a.sad + (b.sad - a.sad) * k,
    a.relaxed + (b.relaxed - a.relaxed) * k,
    a.surprised + (b.surprised - a.surprised) * k,
    a.eyesClosed + (b.eyesClosed - a.eyesClosed) * k,
)

package com.sherley.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sherley.app.ai.Http
import com.sherley.app.ai.LocalLlmClient
import com.sherley.app.ai.Turn
import com.sherley.app.companion.ChatEvent
import com.sherley.app.companion.EventHeuristics
import com.sherley.app.companion.Mood
import com.sherley.app.companion.MoodEngine
import com.sherley.app.companion.MoodState
import com.sherley.app.companion.Needs
import com.sherley.app.companion.Persona
import com.sherley.app.avatar.Reaction
import com.sherley.app.avatar.Reactions
import com.sherley.app.avatar.Region
import com.sherley.app.avatar.TouchKind
import com.sherley.app.config.AppConfig
import com.sherley.app.config.AppSettings
import com.sherley.app.data.AppDatabase
import com.sherley.app.data.BackgroundStore
import com.sherley.app.data.MessageEntity
import com.sherley.app.memory.MemoryManager
import com.sherley.app.reflex.AppLauncher
import com.sherley.app.reflex.ReflexLines
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Everything the main screen needs to draw itself. */
data class UiState(
    /** Sherley's most recent reply (null before the first chat). */
    val latest: MessageEntity? = null,
    val mood: Mood = Mood.CURIOUS,
    val intensity: Float = 0.5f,
    val needs: Needs = Needs(),
    /** True while the local model is working on a reply. */
    val thinking: Boolean = false,
    /** An instant, no-model reaction (to a touch or idle moment) shown in the speech bubble. */
    val reflex: String? = null,
    /** True while she "talks" (drives the mouth). */
    val speaking: Boolean = false,
    /** Bumped when a new VRM file is picked, so the avatar reloads. */
    val avatarVersion: Int = 0,
    /** The latest touch reaction (face flash + gesture). The screen plays it when reactionNonce changes. */
    val reaction: Reaction? = null,
    val reactionSide: Int = 1,
    val reactionNonce: Int = 0,
    /** True while the joint calibration screen is open over the avatar. */
    val calibrating: Boolean = false,
    /** Body action to play (sit_chair, sit_bed, stand, wave, ...). Played when actionNonce changes. */
    val action: String? = null,
    val actionNonce: Int = 0,
    val error: String? = null,
)

/**
 * The conductor. For every chat message it:
 *  1. lets time pass (mood tick), saves your message
 *  2. asks the local Thinai model for the reply (+ events, facts)
 *  3. updates mood from the events, stores facts, saves the reply
 * Touches skip the model: they change mood at once and show a pre-written reaction (ReflexLines).
 */
class ChatViewModel(app: Application) : AndroidViewModel(app) {

    val settings = AppSettings(app)
    val voice = com.sherley.app.voice.Voice(app).also { v ->
        v.pitch = settings.voicePitch
        v.rate = settings.voiceRate
        v.preferredVoice = settings.voiceName
    }
    /** Set when the last run crashed while loading a model and settings were made gentler. */
    val crashNote: String? = settings.recoverFromCrash()
    val backgrounds = BackgroundStore(app)

    private val dao = AppDatabase.get(app).chatDao()
    private val http = Http.client()
    private val llm = LocalLlmClient(settings, http)          // chat: Thinai, on this phone
    private val memory = MemoryManager(dao, settings, llm)

    private var moodState: MoodState =
        MoodState.fromJson(settings.moodStateJson, System.currentTimeMillis())

    private val _ui = MutableStateFlow(
        UiState(mood = moodState.mood, intensity = moodState.intensity, needs = moodState.needs),
    )
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    /** The whole conversation, for the History screen. */
    val history: Flow<List<MessageEntity>> = dao.observeAll()

    private val tapTimes = ArrayDeque<Long>()
    private var lastTouchNote: String? = null
    private var lastTouchAt = 0L
    private var lastActivityAt = System.currentTimeMillis()
    private var reflexJob: Job? = null
    private var speakJob: Job? = null

    init {
        val why = com.sherley.app.config.CrashInfo.describe(app)
        val note = listOfNotNull(crashNote, why).joinToString("\n")
        if (note.isNotBlank()) _ui.update { it.copy(error = note) }
        refreshMood()
        viewModelScope.launch {
            val last = dao.lastModelMessage()
            _ui.update { it.copy(latest = last) }
        }
    }

    // ---------------------------------------------------------------------
    // Public actions used by the screens
    // ---------------------------------------------------------------------
    fun send(text: String) {
        val trimmed = text.trim()
        val appName = AppLauncher.parse(trimmed)
        val act = parseAction(trimmed)
        if (act != null && !_ui.value.thinking) { doAction(trimmed, act); return }
        if (appName != null && !_ui.value.thinking) openApp(trimmed, appName) else launchTurn(trimmed)
    }

    fun requestAction(name: String) {
        if (name in SEATED) sitting = true
        if (name == "stand" || name == "room:bed_approach" || name == "room:window_view" || name == "room:spawn") sitting = false
        lastActivityAt = System.currentTimeMillis()
        _ui.update { it.copy(action = name, actionNonce = it.actionNonce + 1) }
    }

    private var sitting = false
    private val SEATED = setOf("sit_chair", "sit_bed", "room:bed_sit", "room:bed_lie", "room:desk_seat", "room:reading_seat", "room:rug_meditate")

    private fun parseAction(text: String): String? {
        val s = text.lowercase().trim().trimEnd('.', '!', '?')
        fun has(vararg w: String) = w.any { Regex("\\b$it\\b").containsMatchIn(s) }
        val sit = has("sit", "seat", "perch")
        val lie = has("lie", "lay", "sleep", "nap", "rest")
        val go = has("go", "walk", "come", "head", "move")
        return when {
            Regex("^(please )?(stand( up)?|get up|get off)$").containsMatchIn(s) -> "stand"
            has("bed") && lie -> "room:bed_lie"
            has("bed") && sit -> "room:bed_sit"
            has("bed") && go -> "room:bed_approach"
            (has("chair", "desk") && has("reading", "armchair", "sofa")) && (sit || go) -> "room:reading_seat"
            has("reading") && (sit || go) -> "room:reading_seat"
            (has("desk", "chair", "study") && sit) -> "room:desk_seat"
            (has("desk") && go) -> "room:desk_approach"
            has("floor", "rug", "meditate", "meditation") && (sit || go || has("meditate")) -> "room:rug_meditate"
            has("yoga") -> "room:yoga_spot"
            has("tv", "television") && (go || has("watch")) -> "room:tv_approach"
            has("window") && (go || has("look")) -> "room:window_view"
            has("door", "entrance") && go -> "room:entry"
            has("games?", "gaming") && go -> "room:game_approach"
            Regex("(go|walk|come|head) (to )?(the )?(middle|center|centre)").containsMatchIn(s) -> "room:spawn"
            Regex("^(please )?(go for a )?(walk|wander|stroll)( around)?$").containsMatchIn(s) ->
                listOf("room:window_view", "room:rug_watch_tv", "room:tv_approach", "room:entry", "room:game_approach").random()
            Regex("^(please )?(wave|say hi with a wave)$").containsMatchIn(s) -> "wave"
            Regex("^(please )?stretch$").containsMatchIn(s) -> "stretch"
            Regex("^(please )?look around$").containsMatchIn(s) -> "look_around"
            Regex("^(please )?(cheer|celebrate)$").containsMatchIn(s) -> "cheer"
            else -> null
        }
    }

    /** Body commands ("sit on the chair", "wave"...): handled by the app, no language model call. */
    private fun doAction(userText: String, action: String) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            dao.insertMessage(MessageEntity(role = "user", text = userText, timestamp = now))
            requestAction(action)
            val reply = when (action) {
                "room:desk_seat", "sit_chair" -> "Off to the desk. Very Holmesian."
                "room:reading_seat" -> "The reading chair it is."
                "room:bed_sit", "sit_bed" -> "Perching on the edge of the bed."
                "room:bed_lie" -> "Bed time. Wake me for a case."
                "room:rug_meditate" -> "Cross-legged on the rug. Deep thoughts incoming."
                "room:tv_approach", "room:rug_watch_tv" -> "Heading over to the TV."
                "room:window_view" -> "Off to look out of the window."
                "room:yoga_spot" -> "Time for a stretch on the yoga spot."
                "stand" -> "Up I get."
                "room:bed_approach", "room:desk_approach", "room:entry", "room:game_approach", "room:spawn" -> "On my way."
                "wave" -> "Hello there!"
                "stretch" -> "Ahh, I needed that."
                "look_around" -> "Scanning the room for clues..."
                else -> "Hooray!"
            }
            val id = dao.insertMessage(
                MessageEntity(role = "model", text = reply, timestamp = System.currentTimeMillis(), mood = moodState.mood.name),
            )
            _ui.update { it.copy(latest = dao.messageById(id)) }
            speakFor(reply)
        }
    }

    /** "open <app>": launched by the app itself, no language model call. */
    private fun openApp(userText: String, appName: String) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            lastActivityAt = now
            dao.insertMessage(MessageEntity(role = "user", text = userText, timestamp = now))
            val result = AppLauncher.open(getApplication(), appName)
            val reply = when (result) {
                is AppLauncher.Result.Opened -> listOf(
                    "Opening ${result.label}. Off we go!",
                    "${result.label}, coming right up.",
                    "Case file: ${result.label}. Opening it now.",
                ).random()
                is AppLauncher.Result.NotFound ->
                    "Hmm, I can't find an app called \"${result.name}\". Check the spelling? Or try the app list (▦)."
            }
            val id = dao.insertMessage(
                MessageEntity(role = "model", text = reply, timestamp = System.currentTimeMillis(), mood = moodState.mood.name),
            )
            _ui.update { it.copy(latest = dao.messageById(id)) }
            speakFor(reply)
        }
    }

    fun dismissError() = _ui.update { it.copy(error = null) }

    fun setCalibrating(on: Boolean) = _ui.update { it.copy(calibrating = on) }

    fun bumpAvatar() = _ui.update { it.copy(avatarVersion = it.avatarVersion + 1) }

    /** Settings > "Test connection". Sends a tiny request and reports what happened and how long it took. */
    suspend fun testConnection(): String {
        val started = System.currentTimeMillis()
        return try {
            val models = llm.listModels()
            val answer = llm.plainText("Reply with the single word: ok", maxTokens = 300)
            val seconds = (System.currentTimeMillis() - started) / 1000.0
            val used = settings.localModel.ifBlank { models.firstOrNull() ?: "?" }
            "Works. Thinai answered \"${answer.trim().take(40)}\" in ${"%.1f".format(seconds)}s using model $used. " +
                "Installed models: ${if (models.isEmpty()) "none" else models.joinToString()}."
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
    }

    /** Called when the app comes to the foreground: time may have passed. */
    fun refreshMood() {
        moodState = MoodEngine.tick(moodState, System.currentTimeMillis())
        saveMood()
    }

    suspend fun messageById(id: Long): MessageEntity? = dao.messageById(id)

    fun saveInputOffset(x: Float, y: Float) {
        settings.inputOffsetX = x
        settings.inputOffsetY = y
    }

    fun saveBubbleOffset(x: Float, y: Float) {
        settings.bubbleOffsetX = x
        settings.bubbleOffsetY = y
    }

    fun setBackground(key: String, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) { backgrounds.save(key, uri) }
    }

    fun clearBackground(key: String) {
        viewModelScope.launch(Dispatchers.IO) { backgrounds.clear(key) }
    }

    fun clearEverything() {
        viewModelScope.launch {
            memory.clearAll()
            moodState = MoodState.initial(System.currentTimeMillis())
            saveMood()
            _ui.update { it.copy(latest = null, reflex = null) }
        }
    }

    // ---------------------------------------------------------------------
    // Touch and idle (no language model involved)
    // ---------------------------------------------------------------------
    /** A touch on one of her body parts. Becomes a reaction: mood change, face, gesture and a line. */
    fun touch(kind: TouchKind, region: Region) {
        val now = System.currentTimeMillis()
        var k = kind
        if (k == TouchKind.TAP || k == TouchKind.DOUBLE_TAP) {
            tapTimes.addLast(now)
            while (tapTimes.isNotEmpty() && now - tapTimes.first() > AppConfig.POKE_SPAM_WINDOW_MS) tapTimes.removeFirst()
            if (tapTimes.size >= AppConfig.POKE_SPAM_COUNT) { tapTimes.clear(); k = TouchKind.SPAM }
        }
        val reaction = Reactions.pick(region, k, moodState.mood) ?: return
        moodState = MoodEngine.applyEvents(
            moodState, emptyList(), now,
            companyBoost = 2f, extraNeeds = reaction.tone.needs, extraBoosts = reaction.tone.boosts,
        )
        saveMood()
        lastTouchNote = reaction.note
        lastTouchAt = now
        lastActivityAt = now
        _ui.update {
            it.copy(reaction = reaction, reactionSide = Reactions.sideOf(region), reactionNonce = it.reactionNonce + 1)
        }
        showReflex(reaction.lines.random())
    }

    /** Called every few seconds by the main screen. May make her speak up after a quiet while. */
    fun idleTick() {
        val now = System.currentTimeMillis()
        if (_ui.value.thinking || _ui.value.reflex != null) return
        if (now - lastActivityAt < AppConfig.IDLE_BARK_AFTER_MS) return
        lastActivityAt = now
        moodState = MoodEngine.tick(moodState, now)
        saveMood()
        if (!sitting) {
            requestAction(
                listOf(
                    "look_around", "stretch", "wave", "shy",
                    "room:window_view", "room:rug_watch_tv", "room:reading_seat", "room:desk_seat", "room:bed_sit", "room:rug_meditate",
                    "room:wander", "room:wander",
                ).random(),
            )
        } else if (kotlin.random.Random.nextInt(3) == 0) {
            requestAction("stand")
        }
        showReflex(ReflexLines.idleBark(moodState.mood))
    }

    private fun showReflex(text: String) {
        reflexJob?.cancel()
        _ui.update { it.copy(reflex = text) }
        speakFor(text)
        reflexJob = viewModelScope.launch {
            delay(AppConfig.REFLEX_SHOW_MS)
            _ui.update { it.copy(reflex = null) }
        }
    }

    /**
     * Says the text out loud when her voice works (her mouth follows the real speech), otherwise just
     * moves her mouth for a time proportional to the text length.
     */
    private fun speakFor(text: String, emotion: String? = null, intensity: Int = 2) {
        speakJob?.cancel()
        voice.onSpeaking = { on -> _ui.update { it.copy(speaking = on) } }
        if (settings.voiceEnabled) {
            voice.pitch = settings.voicePitch
            voice.rate = settings.voiceRate
            voice.preferredVoice = settings.voiceName
            if (voice.speak(text, emotion ?: com.sherley.app.companion.EmotionMap.forMood(moodState.mood), intensity)) return
        }
        _ui.update { it.copy(speaking = true) }
        speakJob = viewModelScope.launch {
            delay((text.length * 45L).coerceIn(600L, 8000L))
            _ui.update { it.copy(speaking = false) }
        }
    }

    /** Settings > "Next voice": cycles through the installed voices and says a sample. */
    fun nextVoice() {
        voice.onSpeaking = { on -> _ui.update { it.copy(speaking = on) } }
        voice.pitch = settings.voicePitch
        voice.rate = settings.voiceRate
        settings.voiceName = voice.nextVoice()
    }

    private var testIndex = 0

    /** Settings > "Test voice": each press speaks the same kind of line in the next emotion. */
    fun testVoice() {
        val emotions = listOf("happy", "sad", "angry", "shy", "sleepy", "curious", "excited", "sarcastic", "calm")
        val e = emotions[testIndex++ % emotions.size]
        speakFor("This is how I sound when I feel $e. Elementary, my dear friend.", e, 3)
    }

    override fun onCleared() {
        voice.shutdown()
        super.onCleared()
    }

    // ---------------------------------------------------------------------
    // One conversation turn
    // ---------------------------------------------------------------------
    private fun launchTurn(userText: String) {
        if (userText.isBlank() || _ui.value.thinking) return
        _ui.update { it.copy(thinking = true, error = null, reflex = null) }
        lastActivityAt = System.currentTimeMillis()

        viewModelScope.launch {
            try {
                // Time passes before she answers, so the reply matches her current mood.
                moodState = MoodEngine.tick(moodState, System.currentTimeMillis())
                dao.insertMessage(
                    MessageEntity(role = "user", text = userText, timestamp = System.currentTimeMillis()),
                )
                reply(userText)
            } catch (e: Exception) {
                _ui.update { it.copy(error = e.message ?: "Something went wrong.") }
            } finally {
                lastActivityAt = System.currentTimeMillis()
                _ui.update { it.copy(thinking = false) }
            }
        }
    }

    private suspend fun reply(userText: String) {
        val now = System.currentTimeMillis()
        val userName = settings.userName

        // A recent touch is mentioned once so she can react to it in words.
        val touch = lastTouchNote?.takeIf { now - lastTouchAt < AppConfig.TOUCH_NOTE_VALID_MS }
        lastTouchNote = null

        // Build the prompt: fixed persona + changing context, then the recent turns.
        val system = Persona.systemPrompt(userName) + "\n\n" +
            Persona.dynamicContext(moodState, now, memory.summary(), memory.relevantFacts(userText), userName, touch)

        val recent = dao.lastMessages(settings.historyTurns * 2).reversed()
        val turns = recent.map { Turn(if (it.role == "user") "user" else "model", it.text) }

        val result = llm.chat(system, turns)

        // Events change needs and push moods: the ones the model tagged, plus obvious ones the app
        // spots itself (small local models often forget to tag). Then store memories and the reply.
        val events = result.events + EventHeuristics.detect(userText)
        moodState = MoodEngine.applyEvents(moodState, events, now)
        saveMood()
        memory.addFacts(result.facts)

        val id = dao.insertMessage(
            MessageEntity(
                role = "model",
                text = result.reply,
                timestamp = System.currentTimeMillis(),
                mood = moodState.mood.name,
            ),
        )

        _ui.update { it.copy(latest = dao.messageById(id)) }
        speakFor(result.reply, result.emotion, result.intensity)

        // Housekeeping off the critical path: fold old history into the summary.
        viewModelScope.launch {
            try {
                memory.maybeSummarize()
            } catch (e: Exception) {
                // Summaries are best-effort; try again after the next message.
            }
        }
    }

    private fun saveMood() {
        settings.moodStateJson = moodState.toJson()
        _ui.update {
            it.copy(mood = moodState.mood, intensity = moodState.intensity, needs = moodState.needs)
        }
    }
}

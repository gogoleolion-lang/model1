package com.sherley.app.voice

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * Talks to the HayaiTTS local API (127.0.0.1:11435). Sentences are sent one after another and played as
 * the audio arrives, so she starts talking after the first sentence, not after the whole reply.
 */
class HayaiClient(private val context: Context) {

    @Volatile private var generation = 0
    @Volatile private var track: AudioTrack? = null
    @Volatile private var conn: HttpURLConnection? = null

    var onSpeaking: ((Boolean) -> Unit)? = null
    /** Called on the first failure so the caller can fall back to the phone's own voice. */
    var onFailure: ((String) -> Unit)? = null

    /** Starts the HayaiTTS service if it is installed. Safe to call repeatedly. */
    /** Returns null if the start request went through, or a short reason if it did not. */
    fun wake(): String? = try {
        val i = Intent().setComponent(ComponentName(PKG, "$PKG.tts.HayaiApiService"))
        if (context.startForegroundService(i) == null) "HayaiTTS (with the local API) is not installed, or this phone blocks starting it"
        else null
    } catch (t: Throwable) { "Could not start HayaiTTS: ${t.javaClass.simpleName} ${t.message ?: ""}".trim() }

    /** True if the API answers right now. Call off the main thread. */
    fun alive(): Boolean = try {
        val c = URL("$BASE/health").openConnection() as HttpURLConnection
        c.connectTimeout = 1500; c.readTimeout = 120_000 // the first answer waits for the voice model to load
        val ok = c.responseCode == 200 && JSONObject(c.inputStream.bufferedReader().readText()).optBoolean("ok")
        c.disconnect(); ok
    } catch (_: Throwable) { false }

    /** The extra detail HayaiTTS keeps about its last error or why it last died; empty if unreachable. */
    fun diagnose(): String = try {
        val c = URL("$BASE/health").openConnection() as HttpURLConnection
        c.connectTimeout = 2000; c.readTimeout = 20_000
        val o = JSONObject(c.inputStream.bufferedReader().readText()); c.disconnect()
        listOf(o.optString("lastError"), o.optString("lastExit")).filter { it.isNotBlank() }.joinToString(" | ")
    } catch (_: Throwable) { "HayaiTTS is not answering now (it may have crashed or been stopped by the phone)" }

    /**
     * Makes the speech for every sentence first, then plays it as one piece. Playing while it is still being
     * made sounded choppy on a phone that makes speech slower than it plays, and made the mouth move before
     * there was any sound. The mouth now follows the audio that is really playing.
     */
    fun speak(text: String, emotion: String, intensity: Int) {
        stop()
        val gen = generation
        val sentences = split(text)
        if (sentences.isEmpty()) return
        thread(name = "hayai-voice", isDaemon = true) {
            try {
                val parts = ArrayList<ByteArray>()
                var rate = 24000
                for (s in sentences) {
                    if (gen != generation) return@thread
                    val r = fetch(s, emotion, intensity)
                    rate = r.first
                    parts.add(r.second)
                }
                if (gen != generation) return@thread
                playAll(parts, rate, gen)
            } catch (e: Throwable) {
                if (gen == generation) { onSpeaking?.invoke(false); onFailure?.invoke(e.message ?: e.javaClass.simpleName) }
            }
        }
    }

    fun stop() {
        generation++
        runCatching { conn?.disconnect() }
        runCatching { track?.pause(); track?.flush(); track?.release() }
        track = null
        onSpeaking?.invoke(false)
    }

    /** One sentence in, (sample rate, 16-bit mono audio) out. */
    private fun fetch(text: String, emotion: String, intensity: Int): Pair<Int, ByteArray> {
        val body = JSONObject().put("text", text).put("emotion", emotion).put("intensity", intensity).toString()
        val c = URL("$BASE/speak").openConnection() as HttpURLConnection
        conn = c
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 3000; c.readTimeout = 8 * 60_000
        c.outputStream.use { it.write(body.toByteArray()) }
        if (c.responseCode != 200) {
            val msg = try { c.errorStream?.bufferedReader()?.readText().orEmpty() } catch (_: Throwable) { "" }
            error("HayaiTTS answered ${c.responseCode}: ${msg.take(300)}")
        }
        val rate = c.getHeaderField("X-Sample-Rate")?.toIntOrNull() ?: 24000
        val bytes = c.inputStream.use { it.readBytes() }
        c.disconnect()
        if (bytes.isEmpty()) error("HayaiTTS sent no audio for: ${text.take(40)}")
        return rate to bytes
    }

    private fun playAll(parts: List<ByteArray>, rate: Int, gen: Int) {
        val total = parts.sumOf { it.size }
        val all = ByteArray(total)
        var pos = 0
        for (p in parts) { System.arraycopy(p, 0, all, pos, p.size); pos += p.size }
        val frames = total / 2
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(total)
            .setTransferMode(AudioTrack.MODE_STATIC) // the whole thing is in memory, so it cannot run dry
            .build()
        t.write(all, 0, total)
        track = t
        if (gen != generation) { runCatching { t.release() }; return }
        t.play()
        onSpeaking?.invoke(true)
        try {
            // The mouth moves exactly while sound is coming out.
            while (gen == generation && t.playbackHeadPosition < frames - 64) Thread.sleep(40)
        } finally {
            if (gen == generation) {
                onSpeaking?.invoke(false)
                runCatching { t.stop(); t.release() }
                if (track === t) track = null
            }
        }
    }

    /** Short pieces: the first one is kept brief so speech starts quickly. */
    private fun split(text: String): List<String> {
        val parts = Regex("(?<=[.!?…])\\s+").split(text.trim()).filter { it.isNotBlank() }.toMutableList()
        if (parts.isEmpty()) return emptyList()
        val first = parts[0]
        if (first.length > 140) { // break a long first sentence at a comma
            val cut = first.lastIndexOf(',', 120).takeIf { it > 30 }
            if (cut != null) { parts[0] = first.substring(0, cut + 1); parts.add(1, first.substring(cut + 1).trim()) }
        }
        return parts
    }

    companion object {
        const val PKG = "dev.ahmedmohamed.hayaitts"
        const val BASE = "http://127.0.0.1:11435"
    }
}

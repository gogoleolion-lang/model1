package com.sherley.app.config

import android.content.Context

/** Everything the user can change at runtime, saved on the phone (SharedPreferences). */
class AppSettings(context: Context) {

    private val prefs = context.getSharedPreferences("sherley_settings", Context.MODE_PRIVATE)

    private fun str(key: String, default: String) = prefs.getString(key, default) ?: default
    private fun putStr(key: String, value: String) = prefs.edit().putString(key, value).apply()
    private fun putBool(key: String, value: Boolean) = prefs.edit().putBoolean(key, value).apply()

    // ---- Editable in the Settings screen -------------------------------
    /** Where Thinai's local server listens. */
    var localUrl: String
        get() = str("local_url", AppConfig.DEFAULT_LOCAL_URL)
        set(v) = putStr("local_url", v.trim().ifBlank { AppConfig.DEFAULT_LOCAL_URL })

    /** Model name inside Thinai. Blank means "use the first model Thinai reports". */
    var localModel: String
        get() = str("local_model", "")
        set(v) = putStr("local_model", v.trim())

    var userName: String
        get() = str("user_name", AppConfig.DEFAULT_USER_NAME)
        set(v) = putStr("user_name", v.trim().ifBlank { AppConfig.DEFAULT_USER_NAME })

    var historyTurns: Int
        get() = prefs.getInt("history_turns", AppConfig.DEFAULT_HISTORY_TURNS)
        set(v) = prefs.edit().putInt("history_turns", v.coerceIn(2, 30)).apply()

    // ---- Avatar switches ---------------------------------------------------
    /** Show the 3D body at all. */
    var avatarEnabled: Boolean
        get() = prefs.getBoolean("avatar_enabled", true)
        set(v) = putBool("avatar_enabled", v)

    /** Eyes follow your finger. Off by default: needs the SDK's look-at call to behave. */
    var eyeFollow: Boolean
        get() = prefs.getBoolean("eye_follow", false)
        set(v) = putBool("eye_follow", v)

    /** How strongly her face shows moods, 0 (off) to 1. Lower is more natural; 0 keeps the model's own face. */
    var faceStrength: Float
        get() = prefs.getFloat("face_strength", 0.4f)
        set(v) = prefs.edit().putFloat("face_strength", v.coerceIn(0f, 1f)).apply()

    /** Shading: "mtoon" (anime look, default), "pbr" (realistic), "auto" (let the library detect). */
    var renderMode: String
        get() = str("render_mode", "mtoon")
        set(v) = putStr("render_mode", v)

    /** Render quality: low, medium, high, ultra. */
    var quality: String
        get() = str("quality", "high")
        set(v) = putStr("quality", v)

    /** Light brightness (IBL lux, 5000..40000). */
    var lightLevel: Float
        get() = prefs.getFloat("light_level", 22000f)
        set(v) = prefs.edit().putFloat("light_level", v.coerceIn(5000f, 40000f)).apply()

    /** Which room: dream_bedroom, dream_bedroom_2 or dream_bedroom_3. */
    var roomScene: String
        get() = str("room_scene", "dream_bedroom")
        set(v) = putStr("room_scene", v)

    /** Rooms the user imported: list of (id, name). */
    fun userRooms(): List<Pair<String, String>> = try {
        val a = org.json.JSONArray(str("user_rooms", "[]"))
        (0 until a.length()).map { a.getJSONObject(it).let { o -> o.getString("id") to o.getString("name") } }
    } catch (_: Exception) { emptyList() }

    fun addUserRoom(id: String, name: String) {
        val a = org.json.JSONArray()
        (userRooms() + (id to name)).forEach { a.put(org.json.JSONObject().put("id", it.first).put("name", it.second)) }
        putStr("user_rooms", a.toString())
    }

    fun removeUserRoom(id: String) {
        val a = org.json.JSONArray()
        userRooms().filter { it.first != id }.forEach { a.put(org.json.JSONObject().put("id", it.first).put("name", it.second)) }
        putStr("user_rooms", a.toString())
    }

    /** Built-in rooms plus imported ones. */
    fun allRooms(): List<Pair<String, String>> =
        listOf("dream_bedroom" to "Forest", "dream_bedroom_2" to "Starlit", "dream_bedroom_3" to "Peach") + userRooms()

    /** Show the 3D room behind her. */
    var roomEnabled: Boolean
        get() = prefs.getBoolean("room_enabled", true)
        set(v) = putBool("room_enabled", v)

    /** Room turn in degrees (0..360). Adjust if the chair or bed is not behind her when she sits. */
    var roomYaw: Float
        get() = prefs.getFloat("room_yaw", 0f)
        set(v) = prefs.edit().putFloat("room_yaw", v.coerceIn(0f, 360f)).apply()

    /** Camera framing: auto (follows what she does), close, medium, full or wide. Gestures work in all of them. */
    var cameraMode: String
        get() = str("camera_mode", "auto")
        set(v) = putStr("camera_mode", v)

    /** True while a model is loading; if the app finds it still set at start, the last load crashed. */
    var loadingModel: Boolean
        get() = prefs.getBoolean("loading_model", false)
        set(v) = prefs.edit().putBoolean("loading_model", v).commit().let { }

    /**
     * Called once at start. If the previous run died while loading a model, lower the render quality one
     * step (never the look: Anime stays Anime) and return a note for the user; otherwise null.
     */
    fun recoverFromCrash(): String? {
        if (!loadingModel) return null
        loadingModel = false
        return when (quality) {
            "ultra" -> { quality = "high"; "The last model load crashed, so I lowered the quality to high (look unchanged)." }
            "high" -> { quality = "medium"; "The last model load crashed, so I lowered the quality to medium (look unchanged)." }
            "medium" -> { quality = "low"; "The last model load crashed again, so I lowered the quality to low (look unchanged)." }
            else -> "The last model load crashed even at low quality. That model may be too heavy for this phone."
        }
    }

    /** She speaks her replies out loud (phone text-to-speech). */
    var voiceEnabled: Boolean
        get() = prefs.getBoolean("voice_enabled", true)
        set(v) = putBool("voice_enabled", v)

    var voicePitch: Float
        get() = prefs.getFloat("voice_pitch", 1.2f)
        set(v) = prefs.edit().putFloat("voice_pitch", v.coerceIn(0.6f, 1.8f)).apply()

    var voiceRate: Float
        get() = prefs.getFloat("voice_rate", 1.05f)
        set(v) = prefs.edit().putFloat("voice_rate", v.coerceIn(0.6f, 1.6f)).apply()

    /** Keep showing the speech bubble even when her voice works. */
    var textWithVoice: Boolean
        get() = prefs.getBoolean("text_with_voice", false)
        set(v) = putBool("text_with_voice", v)

    /** Name of the chosen text-to-speech voice, blank = automatic. */
    var voiceName: String
        get() = str("voice_name", "")
        set(v) = putStr("voice_name", v)

    /** Joint calibration (JSON), blank = built-in proportions. See avatar/JointCalibration.kt. */
    var calibrationJson: String
        get() = str("calibration", "")
        set(v) = putStr("calibration", v)

    /** Shows touch zones and a diagnostics panel on the main screen. */
    var devMode: Boolean
        get() = prefs.getBoolean("dev_mode", false)
        set(v) = putBool("dev_mode", v)

    /** Draw the mood background image behind the avatar (may hide it, depends on the SDK's surface). */
    var bgBehindAvatar: Boolean
        get() = prefs.getBoolean("bg_behind_avatar", false)
        set(v) = putBool("bg_behind_avatar", v)

    /** Her saved arm/head pose (JSON of 15 numbers), or blank for her natural animation. */
    var poseJson: String
        get() = str("pose_json", "")
        set(v) = putStr("pose_json", v)

    // ---- Saved automatically by the app ----------------------------------
    /** Where the user dragged the text box and the speech bubble (pixels from their default spot). */
    var inputOffsetX: Float
        get() = prefs.getFloat("input_offset_x", 0f)
        set(v) = prefs.edit().putFloat("input_offset_x", v).apply()

    var inputOffsetY: Float
        get() = prefs.getFloat("input_offset_y", 0f)
        set(v) = prefs.edit().putFloat("input_offset_y", v).apply()

    var bubbleOffsetX: Float
        get() = prefs.getFloat("bubble_offset_x", 0f)
        set(v) = prefs.edit().putFloat("bubble_offset_x", v).apply()

    var bubbleOffsetY: Float
        get() = prefs.getFloat("bubble_offset_y", 0f)
        set(v) = prefs.edit().putFloat("bubble_offset_y", v).apply()

    /** Sherley's needs + current mood, as JSON (see MoodState). */
    var moodStateJson: String
        get() = str("mood_state", "")
        set(v) = putStr("mood_state", v)

    /** Rolling summary of old conversations. */
    var summaryText: String
        get() = str("summary_text", "")
        set(v) = putStr("summary_text", v)

    /** Highest message id already folded into the summary. */
    var summarizedUpToId: Long
        get() = prefs.getLong("summarized_up_to", 0L)
        set(v) = prefs.edit().putLong("summarized_up_to", v).apply()
}

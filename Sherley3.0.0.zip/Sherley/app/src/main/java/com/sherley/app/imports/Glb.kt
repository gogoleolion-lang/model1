package com.sherley.app.imports

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Reading and writing the binary glTF (.glb) container. */
object Glb {
    class Parsed(val json: JSONObject, val bin: ByteArray)

    fun isGlb(bytes: ByteArray) = bytes.size > 20 && bytes[0] == 'g'.code.toByte() && bytes[1] == 'l'.code.toByte() &&
        bytes[2] == 'T'.code.toByte() && bytes[3] == 'F'.code.toByte()

    fun parse(bytes: ByteArray): Parsed {
        val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        require(isGlb(bytes)) { "Not a .glb file." }
        var pos = 12
        var json: JSONObject? = null
        var bin = ByteArray(0)
        while (pos + 8 <= bytes.size) {
            val len = b.getInt(pos); val type = b.getInt(pos + 4)
            val start = pos + 8
            if (type == 0x4E4F534A) json = JSONObject(String(bytes, start, len, Charsets.UTF_8))
            else if (type == 0x004E4942) bin = bytes.copyOfRange(start, start + len)
            pos = start + len
        }
        return Parsed(json ?: error("The .glb has no model data."), bin)
    }

    /** Reads only the JSON header (cheap, for a big file). */
    fun readJson(file: java.io.File): JSONObject? = try {
        file.inputStream().use { s ->
            val head = ByteArray(20)
            if (s.read(head) < 20) return null
            val b = ByteBuffer.wrap(head).order(ByteOrder.LITTLE_ENDIAN)
            if (!isGlb(head)) return null
            val len = b.getInt(12)
            if (len <= 0 || len > 64 * 1024 * 1024) return null
            val data = ByteArray(len)
            var off = 0
            while (off < len) { val n = s.read(data, off, len - off); if (n < 0) break; off += n }
            JSONObject(String(data, 0, off, Charsets.UTF_8))
        }
    } catch (_: Throwable) { null }

    fun write(json: JSONObject, bin: ByteArray): ByteArray {
        var js = json.toString().toByteArray(Charsets.UTF_8)
        val jsPad = (4 - js.size % 4) % 4
        val binPad = (4 - bin.size % 4) % 4
        val total = 12 + 8 + js.size + jsPad + 8 + bin.size + binPad
        val out = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN)
        out.putInt(0x46546C67).putInt(2).putInt(total)
        out.putInt(js.size + jsPad).putInt(0x4E4F534A).put(js); repeat(jsPad) { out.put(0x20) }
        out.putInt(bin.size + binPad).putInt(0x004E4942).put(bin); repeat(binPad) { out.put(0) }
        return out.array()
    }
}

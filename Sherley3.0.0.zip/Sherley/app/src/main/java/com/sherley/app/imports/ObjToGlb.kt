package com.sherley.app.imports

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Converts a Wavefront .obj (with its .mtl and png/jpg textures next to it) into a .glb that the 3D
 * engine can load. Static geometry only: one mesh, one piece per material, colours and base-colour textures.
 */
object ObjToGlb {

    private class Mat(val name: String) {
        var kd = floatArrayOf(0.8f, 0.8f, 0.8f)
        var tex: String? = null
    }

    private class Piece(val mat: String) {
        val positions = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val uvs = ArrayList<Float>()
        val indices = ArrayList<Int>()
        val lookup = HashMap<String, Int>()
    }

    fun convert(obj: File): ByteArray {
        val dir = obj.parentFile ?: File(".")
        val v = ArrayList<Float>(); val vt = ArrayList<Float>(); val vn = ArrayList<Float>()
        val mats = HashMap<String, Mat>()
        val pieces = LinkedHashMap<String, Piece>()
        var current = Piece("").also { pieces[""] = it }

        fun loadMtl(name: String) {
            val f = findFile(dir, name) ?: return
            var m: Mat? = null
            f.forEachLine { raw ->
                val l = raw.trim()
                val p = l.split(Regex("\\s+"))
                when (p[0].lowercase()) {
                    "newmtl" -> { m = Mat(l.substringAfter(' ').trim()); mats[m!!.name] = m!! }
                    "kd" -> if (p.size >= 4) m?.kd = floatArrayOf(p[1].toFloat(), p[2].toFloat(), p[3].toFloat())
                    "map_kd" -> m?.tex = l.substringAfter(' ').trim().split(" ").last()
                }
            }
        }

        obj.forEachLine { raw ->
            val l = raw.trim()
            if (l.isEmpty() || l[0] == '#') return@forEachLine
            val p = l.split(Regex("\\s+"))
            when (p[0]) {
                "v" -> { v.add(p[1].toFloat()); v.add(p[2].toFloat()); v.add(p[3].toFloat()) }
                "vt" -> { vt.add(p[1].toFloat()); vt.add(if (p.size > 2) p[2].toFloat() else 0f) }
                "vn" -> { vn.add(p[1].toFloat()); vn.add(p[2].toFloat()); vn.add(p[3].toFloat()) }
                "mtllib" -> loadMtl(l.substringAfter(' ').trim())
                "usemtl" -> {
                    val n = l.substringAfter(' ').trim()
                    current = pieces.getOrPut(n) { Piece(n) }
                }
                "f" -> {
                    val corners = IntArray(p.size - 1)
                    for (i in 1 until p.size) {
                        val parts = p[i].split('/')
                        val vi = idx(parts[0], v.size / 3)
                        val ti = if (parts.size > 1 && parts[1].isNotEmpty()) idx(parts[1], vt.size / 2) else -1
                        val ni = if (parts.size > 2 && parts[2].isNotEmpty()) idx(parts[2], vn.size / 3) else -1
                        val key = "$vi/$ti/$ni"
                        corners[i - 1] = current.lookup.getOrPut(key) {
                            val n = current.positions.size / 3
                            current.positions.add(v[vi * 3]); current.positions.add(v[vi * 3 + 1]); current.positions.add(v[vi * 3 + 2])
                            if (ni >= 0) { current.normals.add(vn[ni * 3]); current.normals.add(vn[ni * 3 + 1]); current.normals.add(vn[ni * 3 + 2]) }
                            else { current.normals.add(0f); current.normals.add(0f); current.normals.add(0f) }
                            if (ti >= 0) { current.uvs.add(vt[ti * 2]); current.uvs.add(1f - vt[ti * 2 + 1]) } else { current.uvs.add(0f); current.uvs.add(0f) }
                            n
                        }
                    }
                    for (i in 1 until corners.size - 1) {
                        current.indices.add(corners[0]); current.indices.add(corners[i]); current.indices.add(corners[i + 1])
                    }
                }
            }
        }

        val used = pieces.values.filter { it.indices.isNotEmpty() }
        require(used.isNotEmpty()) { "The .obj file has no faces." }
        for (pc in used) fillNormals(pc)

        // ---- build the glb ----
        val bin = ByteArrayOutputStream()
        val views = JSONArray(); val accessors = JSONArray()
        fun align() { while (bin.size() % 4 != 0) bin.write(0) }
        fun addView(bytes: ByteArray, target: Int?): Int {
            align()
            val o = JSONObject().put("buffer", 0).put("byteOffset", bin.size()).put("byteLength", bytes.size)
            if (target != null) o.put("target", target)
            bin.write(bytes); views.put(o); return views.length() - 1
        }
        fun floats(a: List<Float>): ByteArray { val b = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); a.forEach { b.putFloat(it) }; return b.array() }
        fun ints(a: List<Int>): ByteArray { val b = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); a.forEach { b.putInt(it) }; return b.array() }
        fun addAcc(view: Int, comp: Int, count: Int, type: String, min: List<Float>? = null, max: List<Float>? = null): Int {
            val o = JSONObject().put("bufferView", view).put("componentType", comp).put("count", count).put("type", type)
            if (min != null) { o.put("min", JSONArray(min)); o.put("max", JSONArray(max)) }
            accessors.put(o); return accessors.length() - 1
        }

        val materials = JSONArray(); val images = JSONArray(); val textures = JSONArray()
        val imageIndex = HashMap<String, Int>()
        val prims = JSONArray()
        for (pc in used) {
            val n = pc.positions.size / 3
            var mn = floatArrayOf(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE); var mx = floatArrayOf(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
            for (i in 0 until n) for (c in 0..2) { val x = pc.positions[i * 3 + c]; if (x < mn[c]) mn[c] = x; if (x > mx[c]) mx[c] = x }
            val aPos = addAcc(addView(floats(pc.positions), 34962), 5126, n, "VEC3", mn.toList(), mx.toList())
            val aNor = addAcc(addView(floats(pc.normals), 34962), 5126, n, "VEC3")
            val aUv = addAcc(addView(floats(pc.uvs), 34962), 5126, n, "VEC2")
            val aIdx = addAcc(addView(ints(pc.indices), 34963), 5125, pc.indices.size, "SCALAR")

            val m = mats[pc.mat]
            val pbr = JSONObject().put("baseColorFactor", JSONArray(listOf(1.0, 1.0, 1.0, 1.0))).put("metallicFactor", 0.0).put("roughnessFactor", 0.9)
            val texFile = m?.tex?.let { findFile(dir, it) }
            if (texFile != null && texFile.extension.lowercase() in setOf("png", "jpg", "jpeg")) {
                val im = imageIndex.getOrPut(texFile.path) {
                    val view = addView(texFile.readBytes(), null)
                    images.put(JSONObject().put("bufferView", view).put("mimeType", if (texFile.extension.lowercase() == "png") "image/png" else "image/jpeg"))
                    textures.put(JSONObject().put("source", images.length() - 1).put("sampler", 0))
                    textures.length() - 1
                }
                pbr.put("baseColorTexture", JSONObject().put("index", im))
            } else {
                val kd = m?.kd ?: floatArrayOf(0.8f, 0.8f, 0.8f)
                pbr.put("baseColorFactor", JSONArray(listOf(kd[0].toDouble(), kd[1].toDouble(), kd[2].toDouble(), 1.0)))
            }
            materials.put(JSONObject().put("name", pc.mat.ifEmpty { "default" }).put("pbrMetallicRoughness", pbr).put("doubleSided", true))
            prims.put(
                JSONObject().put("attributes", JSONObject().put("POSITION", aPos).put("NORMAL", aNor).put("TEXCOORD_0", aUv))
                    .put("indices", aIdx).put("material", materials.length() - 1),
            )
        }

        val root = JSONObject()
            .put("asset", JSONObject().put("version", "2.0").put("generator", "sherley-obj"))
            .put("scene", 0).put("scenes", JSONArray().put(JSONObject().put("nodes", JSONArray().put(0))))
            .put("nodes", JSONArray().put(JSONObject().put("mesh", 0).put("name", "obj")))
            .put("meshes", JSONArray().put(JSONObject().put("primitives", prims)))
            .put("materials", materials).put("accessors", accessors).put("bufferViews", views)
            .put("buffers", JSONArray().put(JSONObject().put("byteLength", bin.size())))
        if (images.length() > 0) {
            root.put("images", images).put("textures", textures)
                .put("samplers", JSONArray().put(JSONObject().put("magFilter", 9729).put("minFilter", 9987).put("wrapS", 10497).put("wrapT", 10497)))
        }
        return Glb.write(root, bin.toByteArray())
    }

    private fun idx(s: String, count: Int): Int {
        val i = s.toInt()
        return if (i < 0) count + i else i - 1
    }

    private fun findFile(dir: File, name: String): File? {
        val base = name.replace('\\', '/').substringAfterLast('/')
        return dir.walkTopDown().firstOrNull { it.isFile && it.name.equals(base, ignoreCase = true) }
    }

    /** Smooth normals from the faces, for vertices the file gave no normal to. */
    private fun fillNormals(pc: Piece) {
        val n = pc.positions.size / 3
        val missing = BooleanArray(n) { pc.normals[it * 3] == 0f && pc.normals[it * 3 + 1] == 0f && pc.normals[it * 3 + 2] == 0f }
        if (missing.none { it }) return
        val acc = FloatArray(n * 3)
        var i = 0
        while (i < pc.indices.size) {
            val a = pc.indices[i]; val b = pc.indices[i + 1]; val c = pc.indices[i + 2]
            val ux = pc.positions[b * 3] - pc.positions[a * 3]; val uy = pc.positions[b * 3 + 1] - pc.positions[a * 3 + 1]; val uz = pc.positions[b * 3 + 2] - pc.positions[a * 3 + 2]
            val wx = pc.positions[c * 3] - pc.positions[a * 3]; val wy = pc.positions[c * 3 + 1] - pc.positions[a * 3 + 1]; val wz = pc.positions[c * 3 + 2] - pc.positions[a * 3 + 2]
            val nx = uy * wz - uz * wy; val ny = uz * wx - ux * wz; val nz = ux * wy - uy * wx
            for (k in intArrayOf(a, b, c)) { acc[k * 3] += nx; acc[k * 3 + 1] += ny; acc[k * 3 + 2] += nz }
            i += 3
        }
        for (k in 0 until n) if (missing[k]) {
            val len = Math.sqrt((acc[k * 3] * acc[k * 3] + acc[k * 3 + 1] * acc[k * 3 + 1] + acc[k * 3 + 2] * acc[k * 3 + 2]).toDouble()).toFloat().coerceAtLeast(1e-6f)
            pc.normals[k * 3] = acc[k * 3] / len; pc.normals[k * 3 + 1] = acc[k * 3 + 1] / len; pc.normals[k * 3 + 2] = acc[k * 3 + 2] / len
        }
    }
}

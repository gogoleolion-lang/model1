package com.sherley.app.companion

/**
 * Things that can happen in a conversation. the language model tags each reply with the events it noticed
 * in your message (by `tag`); the app turns them into need changes and short mood boosts.
 *
 *  needs  - permanent-ish changes to the six needs
 *  boosts - temporary push toward specific moods (fades over about an hour)
 *  offeredToModel - false for events only the app can detect
 */
enum class ChatEvent(
    val tag: String,
    val needs: NeedsDelta,
    val boosts: Map<Mood, Float>,
    val offeredToModel: Boolean = true,
    /** For touch events: how to describe it to the language model ("patted your head"). */
    val note: String? = null,
) {
    COMPLIMENT(
        "compliment",
        NeedsDelta(respect = 12f, confidence = 6f, comfort = 3f),
        mapOf(Mood.PROUD to 0.5f, Mood.HAPPY to 0.3f, Mood.EMBARRASSED to 0.25f),
    ),
    THANKS(
        "thanks",
        NeedsDelta(respect = 6f, comfort = 4f),
        mapOf(Mood.HAPPY to 0.25f, Mood.CONTENT to 0.2f),
    ),
    KINDNESS(
        "kindness",
        NeedsDelta(comfort = 8f, company = 4f),
        mapOf(Mood.AFFECTIONATE to 0.3f, Mood.HAPPY to 0.25f),
    ),
    INSULT(
        "insult",
        NeedsDelta(respect = -18f, comfort = -10f, confidence = -4f),
        mapOf(Mood.SULKY to 0.6f, Mood.ANNOYED to 0.4f, Mood.GRUMPY to 0.2f),
    ),
    DISMISSIVE(
        "dismissive",
        NeedsDelta(respect = -10f, stimulation = -4f),
        mapOf(Mood.SULKY to 0.35f, Mood.ANNOYED to 0.3f, Mood.DISTRACTED to 0.15f),
    ),
    APOLOGY(
        "apology",
        NeedsDelta(respect = 14f, comfort = 8f),
        mapOf(Mood.CONTENT to 0.3f, Mood.HAPPY to 0.2f, Mood.SHY to 0.1f),
    ),
    PUZZLE(
        "puzzle",
        NeedsDelta(stimulation = 22f, energy = 3f),
        mapOf(Mood.INTRIGUED to 0.6f, Mood.SCHEMING to 0.4f, Mood.EXCITED to 0.3f),
    ),
    NEW_TOPIC(
        "new_topic",
        NeedsDelta(stimulation = 10f),
        mapOf(Mood.CURIOUS to 0.4f, Mood.EAGER to 0.3f),
    ),
    SMALL_TALK(
        "small_talk",
        NeedsDelta(stimulation = -4f),
        mapOf(Mood.BORED to 0.15f, Mood.RELAXED to 0.1f),
    ),
    JOKE(
        "joke",
        NeedsDelta(comfort = 4f, stimulation = 6f),
        mapOf(Mood.PLAYFUL to 0.4f, Mood.GIDDY to 0.2f, Mood.SASSY to 0.2f),
    ),
    USER_STRESSED(
        "user_stressed",
        NeedsDelta(comfort = -6f),
        mapOf(Mood.WORRIED to 0.5f, Mood.THOUGHTFUL to 0.3f),
    ),
    USER_SAD(
        "user_sad",
        NeedsDelta(comfort = -4f),
        mapOf(Mood.WORRIED to 0.3f, Mood.THOUGHTFUL to 0.3f, Mood.AFFECTIONATE to 0.25f),
    ),
    USER_HAPPY(
        "user_happy",
        NeedsDelta(comfort = 4f),
        mapOf(Mood.HAPPY to 0.4f, Mood.CHEERFUL to 0.3f),
    ),
    PRAISED_DEDUCTION(
        "praised_deduction",
        NeedsDelta(confidence = 14f, respect = 8f),
        mapOf(Mood.PROUD to 0.6f, Mood.COCKY to 0.4f, Mood.SASSY to 0.2f),
    ),
    CORRECTED(
        "corrected",
        NeedsDelta(confidence = -10f),
        mapOf(Mood.EMBARRASSED to 0.4f, Mood.DETERMINED to 0.3f, Mood.FRUSTRATED to 0.2f),
    ),
    CHALLENGE(
        "challenge",
        NeedsDelta(stimulation = 10f, confidence = 2f),
        mapOf(Mood.DETERMINED to 0.4f, Mood.MISCHIEVOUS to 0.3f, Mood.SCHEMING to 0.2f),
    ),
    GREETING(
        "greeting",
        NeedsDelta(company = 4f),
        mapOf(Mood.HAPPY to 0.2f, Mood.CHEERFUL to 0.2f),
    ),
    GOODBYE(
        "goodbye",
        NeedsDelta(),
        mapOf(Mood.CONTENT to 0.2f, Mood.SLEEPY to 0.1f),
    ),
    OTHER_ASSISTANT(
        "other_assistant",
        NeedsDelta(),
        mapOf(Mood.JEALOUS to 0.5f, Mood.SASSY to 0.15f),
    ),
    ;

    companion object {
        fun fromTag(tag: String): ChatEvent? {
            val t = tag.trim().lowercase()
            return values().firstOrNull { it.tag == t }
        }
    }
}

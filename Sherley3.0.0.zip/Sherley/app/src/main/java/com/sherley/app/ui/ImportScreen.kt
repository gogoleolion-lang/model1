package com.sherley.app.ui

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sherley.app.config.AppSettings
import com.sherley.app.imports.Importer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Pick a .unitypackage, .zip, .vrm, .glb or .obj; see what is inside; use it as a room or as her body. */
@Composable
fun ImportScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val settings = remember { AppSettings(context) }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var scan by remember { mutableStateOf<Importer.Scan?>(null) }
    var rooms by remember { mutableStateOf(settings.userRooms()) }

    fun nameOf(uri: Uri): String = try {
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) c.getString(i) else null
        } ?: "file"
    } catch (_: Exception) { "file" }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true; message = "Reading the file…"; scan = null
        scope.launch {
            try {
                val s = withContext(Dispatchers.IO) { Importer.scan(context, uri, nameOf(uri)) }
                scan = s
                val skippedText = if (s.skipped.isEmpty()) "" else
                    " Not supported yet and skipped: " + s.skipped.entries.joinToString { "${it.value} × .${it.key}" } + "."
                message = if (s.candidates.isEmpty()) "Nothing I can use was found in this file.$skippedText"
                else "Found ${s.candidates.size} usable file(s).$skippedText"
            } catch (e: Throwable) {
                message = "Could not read it: ${e.message ?: e.javaClass.simpleName}"
            } finally { busy = false }
        }
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).windowInsetsPadding(WindowInsets.safeDrawing)) {
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onBack) { Text("‹ Back") }
                    Text("Import rooms and models", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
            item {
                Text(
                    "Works with .unitypackage, .zip, .vrm, .glb and .obj (with .mtl and pictures). " +
                        "FBX and separate-file glTF are recognised but cannot be loaded yet. " +
                        "A room gets a guessed size and floor; she can walk in it, but there are no bed or chair spots.",
                    fontSize = 13.sp,
                )
            }
            item {
                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text(if (busy) "Working…" else "Choose a file")
                }
            }
            message?.let { m -> item { Text(m, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary) } }

            val cands = scan?.candidates.orEmpty()
            items(cands) { c ->
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(c.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("%s · %.1f MB".format(if (c.kind == Importer.Kind.AVATAR) "model" else "room", c.size / 1048576.0), fontSize = 12.sp)
                    Row {
                        if (c.kind == Importer.Kind.ROOM) TextButton(enabled = !busy, onClick = {
                            busy = true; message = "Fitting the room…"
                            scope.launch {
                                message = try {
                                    val r = withContext(Dispatchers.IO) { Importer.useAsRoom(context, settings, c) }
                                    rooms = settings.userRooms(); vm.bumpAvatar(); r
                                } catch (e: Throwable) { "Could not use it as a room: ${e.message ?: e.javaClass.simpleName}" }
                                busy = false
                            }
                        }) { Text("Use as room") }
                        if (c.kind == Importer.Kind.AVATAR) TextButton(enabled = !busy, onClick = {
                            busy = true
                            scope.launch {
                                val ok = withContext(Dispatchers.IO) { Importer.useAsAvatar(context, c) }
                                if (ok) vm.bumpAvatar()
                                message = if (ok) "She is wearing the new model." else "Could not copy the model."
                                busy = false
                            }
                        }) { Text("Use as her model") }
                    }
                }
            }

            if (rooms.isNotEmpty()) {
                item { Text("Your imported rooms", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp)) }
                items(rooms) { (id, name) ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name, fontSize = 14.sp)
                        Row {
                            TextButton(onClick = { settings.roomScene = id; vm.bumpAvatar(); message = "Switched to $name." }) { Text("Use") }
                            TextButton(onClick = {
                                Importer.deleteRoom(context, settings, id); rooms = settings.userRooms(); vm.bumpAvatar()
                            }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}

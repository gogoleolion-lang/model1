package com.sherley.app.config

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build

/**
 * Finds out why the app died last time and says it in one line, because on a phone there is no log to read.
 * Two sources: a Java/Kotlin crash (saved by our handler, including out-of-memory) and Android's own record of
 * how the previous process ended (native crash, killed for low memory...).
 */
object CrashInfo {
    private const val PREFS = "sherley_crash"

    fun install(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            try {
                val rt = Runtime.getRuntime()
                val text = "${e.javaClass.simpleName}: ${e.message.orEmpty().take(160)} " +
                    "(heap ${(rt.totalMemory() - rt.freeMemory()) shr 20} of ${rt.maxMemory() shr 20} MB)"
                prefs.edit().putString("jvm", text).commit()
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, e)
        }
    }

    /** One line about the last crash, or null if the last run ended normally. Shown once. */
    fun describe(context: Context): String? {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val parts = ArrayList<String>()
        prefs.getString("jvm", null)?.let {
            parts.add("Last crash: $it")
            prefs.edit().remove("jvm").apply()
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val info = am.getHistoricalProcessExitReasons(context.packageName, 0, 1).firstOrNull()
                if (info != null && info.timestamp > prefs.getLong("seen", 0L)) {
                    prefs.edit().putLong("seen", info.timestamp).apply()
                    val reason = when (info.reason) {
                        ApplicationExitInfo.REASON_CRASH_NATIVE -> "native crash (inside the 3D engine)"
                        ApplicationExitInfo.REASON_CRASH -> "app crash"
                        ApplicationExitInfo.REASON_LOW_MEMORY -> "killed by Android for low memory"
                        ApplicationExitInfo.REASON_SIGNALED -> "killed by a signal"
                        ApplicationExitInfo.REASON_ANR -> "app not responding (took too long)"
                        ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "killed for using too many resources"
                        else -> null
                    }
                    if (reason != null) parts.add("Android says the last run ended: $reason. ${info.description.orEmpty().take(120)}")
                }
            } catch (_: Throwable) {
            }
        }
        return parts.takeIf { it.isNotEmpty() }?.joinToString("\n")
    }
}

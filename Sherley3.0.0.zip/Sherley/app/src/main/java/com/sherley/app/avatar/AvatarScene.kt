package com.sherley.app.avatar

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neethu.corelib.AmbientOcclusionQuality
import com.neethu.corelib.AvatarConfig
import com.neethu.corelib.CameraShot
import com.neethu.corelib.WalkPhase
import com.sherley.app.config.AppSettings
import com.neethu.corelib.LightingRig
import com.neethu.corelib.ToneMappingMode
import com.neethu.corelib.AvatarView
import com.neethu.corelib.QualityPreset
import com.neethu.corelib.RenderMode
import com.neethu.corelib.rememberAvatarController
import com.sherley.app.companion.Mood
import kotlinx.coroutines.delay

/**
 * The 3D body. Loads the VRM (picked file first, then the bundled one), shows it full screen,
 * and drives her face and pose.
 *
 * version: change it to force a reload (after picking a new VRM file in Settings).
 * onBody:  hands the AvatarBody to the caller (touch layer, camera buttons).
 * devMode: shows a panel with the model state, its expression names and test buttons.
 */
@Composable
fun AvatarScene(
    version: Int,
    mood: Mood,
    intensity: Float,
    speaking: Boolean,
    flash: Face?,
    flashKey: Int,
    pose: PoseController,
    faceStrength: Float,
    devMode: Boolean,
    renderMode: String = "mtoon",
    quality: String = "high",
    lightLevel: Float = 22000f,
    roomEnabled: Boolean = true,
    roomScene: String = "dream_bedroom",
    cameraMode: String = "auto",
    cameraNonce: Int = 0,
    roomYaw: Float = 0f,
    action: String? = null,
    actionNonce: Int = 0,
    modifier: Modifier = Modifier,
    onBody: (AvatarBody) -> Unit = {},
) {
    val context = LocalContext.current
    val controller = rememberAvatarController()
    val renderSettings = remember(renderMode, quality, lightLevel) {
        val preset = when (quality) {
            "low" -> QualityPreset.LOW
            "medium" -> QualityPreset.MEDIUM
            "ultra" -> QualityPreset.ULTRA
            else -> QualityPreset.HIGH
        }
        when (renderMode) {
            // Anime shading: flat, clean colours as the artist painted them.
            "pbr" -> preset.toRenderSettings(iblIntensity = lightLevel, renderMode = RenderMode.PBR, showFps = false)
            // Soft: PBR but with the things that make skin look grey and dead turned off
            // (strong ambient shadowing, film tone curve, hard rim light), plus extra fill light.
            "soft" -> preset.toRenderSettings(iblIntensity = lightLevel * 1.4f, renderMode = RenderMode.PBR, showFps = false)
                .copy(
                    ambientOcclusion = AmbientOcclusionQuality.OFF,
                    toneMapping = ToneMappingMode.LINEAR,
                    lightingRig = LightingRig.KEY_FILL,
                    bloomEnabled = false,
                    enhanceMaterials = false,
                )
            else -> preset.toRenderSettings(iblIntensity = lightLevel, renderMode = RenderMode.MTOON, showFps = false)
                .copy(
                    ambientOcclusion = AmbientOcclusionQuality.OFF,
                    bloomEnabled = false,
                    // Anime shading does not need big shadow maps; smaller ones keep detailed models stable.
                    shadowMapSize = minOf(preset.toRenderSettings().shadowMapSize, 1024),
                )
        }
    }
    val config = remember { AvatarConfig(renderSettings = renderSettings) }
    val body = remember(controller) { AvatarBody(controller) }
    var status by remember { mutableStateOf("starting") }

    LaunchedEffect(body) { onBody(body) }

    // Re-apply when the user changes shading, quality or light in Settings (render mode reloads the model).
    LaunchedEffect(renderSettings) {
        try { controller.updateRenderSettings(renderSettings) } catch (_: Throwable) {}
    }

    LaunchedEffect(body, version) {
        // Crash guard: if the app dies while this flag is set, the next start switches to gentler settings.
        AppSettings(context).loadingModel = true
        val file = AvatarModel.pickedFile(context)
        val asset = AvatarModel.bundledAsset(context)
        val force = version > 0
        when {
            file != null -> { body.loadFile(file, force); status = "picked file: ${body.stateText()}" }
            asset != null -> { body.loadAsset(asset, force); status = "$asset: ${body.stateText()}" }
            else -> status = "no .vrm found: put one in assets/vrms or pick one in Settings"
        }
        if (body.isReady()) {
            delay(300)
            status += if (body.playIdle()) " | idle animation started" else " | idle animation was not accepted"
        }
        // Give the first frames (where shader compilation can crash) a few seconds before trusting the load.
        delay(8_000)
        AppSettings(context).loadingModel = false
    }

    // The 3D bedroom (a real scene with furniture), loaded once the model is ready.
    val scope = rememberCoroutineScope()
    val director = remember(body) { RoomDirector(context, body, scope) }
    var roomOn by remember { mutableStateOf(false) }
    LaunchedEffect(body, version, roomEnabled, roomScene, renderSettings.renderMode) {
        roomOn = false
        if (!roomEnabled) { director.unload(); return@LaunchedEffect }
        var waited = 0
        while (!body.isReady() && waited < 120) { delay(500); waited++ }
        delay(800)
        roomOn = director.load(roomScene)
        if (roomOn) {
            delay(1_000)
            director.placeAtSpawn()
            status += " | room loaded"
        } else {
            status += " | room failed to load"
        }
    }

    // The camera follows her (it stays locked on her body while she moves). Which framing it uses depends on
    // the chosen mode; in "auto" it picks wide while she walks, full body in the room, closer when chatting.
    // Finger gestures (orbit, zoom, pan) work on top of any mode; "Reset camera" re-applies the framing.
    LaunchedEffect(body, cameraMode, cameraNonce) {
        var last: CameraShot? = null
        if (cameraNonce > 0) try { controller.resetCamera() } catch (_: Throwable) {}
        while (true) {
            delay(400)
            if (!body.isReady()) continue
            val walking = controller.getWalkState()?.phase.let { it != null && it != WalkPhase.IDLE }
            val shot = when (cameraMode) {
                "close" -> CameraShot.CLOSE_UP
                "medium" -> CameraShot.MEDIUM_SHOT
                "full" -> CameraShot.FULL_SHOT
                "wide" -> CameraShot.LONG_SHOT
                else -> when {
                    walking -> CameraShot.LONG_SHOT
                    roomOn -> CameraShot.FULL_SHOT
                    else -> CameraShot.MEDIUM_SHOT
                }
            }
            if (shot != last) {
                try { controller.setCameraShot(shot) } catch (_: Throwable) {}
                last = shot
            }
        }
    }

    LaunchedEffect(actionNonce) {
        val name = action ?: return@LaunchedEffect
        if (actionNonce == 0 || !body.isReady()) return@LaunchedEffect
        when {
            name == "stand" -> if (roomOn) director.standUp() else body.stand()
            name.startsWith("room:") -> {
                val id = name.removePrefix("room:")
                if (roomOn) { if (id == "wander") director.wander() else director.go(id) }
                else when (id) { // no room: fall back to the simple sitting animations
                    "desk_seat", "reading_seat" -> body.play("sit_chair", true)
                    "bed_sit", "bed_lie", "rug_meditate" -> body.play("sit_bed", true)
                }
            }
            name == "sit_chair" || name == "sit_bed" -> body.play(name, true)
            else -> {
                if (roomOn && (director.posture != "standing" || director.busy)) return@LaunchedEffect
                if (body.play(name, false)) {
                    delay(((body.durationSeconds() + 0.3f) * 1000).toLong())
                    if (!roomOn || director.posture == "standing") body.stand()
                }
            }
        }
    }

    AvatarDriver(body, mood, intensity, speaking, flash, flashKey, pose, faceStrength)

    Box(modifier) {
        AvatarView(controller = controller, modifier = Modifier.fillMaxSize(), config = config)

        if (devMode) {
            Column(
                Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .heightIn(max = 220.dp)
                    .background(Color(0xCC000000))
                    .padding(8.dp)
                    .verticalScroll(rememberScrollState()),
            ) {
                Text("Look asked: $renderMode | library detected: ${controller.detectedRenderMode.value}", color = Color.Yellow, fontSize = 11.sp)
                Text("Avatar: $status", color = Color.White, fontSize = 11.sp)
                Text("Expressions in this model: ${body.expressionNames().joinToString()}", color = Color.LightGray, fontSize = 10.sp)
                TextButton(onClick = { status += if (body.playIdle()) " | idle ok" else " | idle failed" }) {
                    Text("Play idle animation", fontSize = 10.sp)
                }
                Row {
                    for (p in listOf("joy", "angry", "sad", "relaxed", "surprised", "blink", "aa")) {
                        TextButton(onClick = { body.setExpression(p, 1f) }) { Text(p, fontSize = 10.sp) }
                    }
                }
            }
        }
    }
}

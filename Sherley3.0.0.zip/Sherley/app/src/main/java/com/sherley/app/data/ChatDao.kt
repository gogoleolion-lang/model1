package com.sherley.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {

    // ---- Messages -------------------------------------------------------
    @Insert
    suspend fun insertMessage(message: MessageEntity): Long

    @Query("SELECT * FROM messages WHERE id = :id")
    suspend fun messageById(id: Long): MessageEntity?

    /** Newest first. Reverse it before sending to the language model. */
    @Query("SELECT * FROM messages ORDER BY id DESC LIMIT :limit")
    suspend fun lastMessages(limit: Int): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE role = 'model' ORDER BY id DESC LIMIT 1")
    suspend fun lastModelMessage(): MessageEntity?

    @Query("SELECT * FROM messages ORDER BY id ASC")
    fun observeAll(): Flow<List<MessageEntity>>

    @Query("SELECT COUNT(*) FROM messages WHERE id > :afterId")
    suspend fun countAfter(afterId: Long): Int

    @Query("SELECT * FROM messages WHERE id > :afterId ORDER BY id ASC LIMIT :limit")
    suspend fun after(afterId: Long, limit: Int): List<MessageEntity>

    @Query("DELETE FROM messages")
    suspend fun clearMessages()

    // ---- Facts ----------------------------------------------------------
    @Insert
    suspend fun insertFact(fact: FactEntity)

    @Query("SELECT * FROM facts ORDER BY id ASC")
    suspend fun allFacts(): List<FactEntity>

    @Query("DELETE FROM facts")
    suspend fun clearFacts()
}

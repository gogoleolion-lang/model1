package com.sherley.app.companion

import org.json.JSONObject

/** How much one chat event changes each need. Positive = fills the need, negative = drains it. */
data class NeedsDelta(
    val energy: Float = 0f,
    val stimulation: Float = 0f,
    val company: Float = 0f,
    val respect: Float = 0f,
    val comfort: Float = 0f,
    val confidence: Float = 0f,
)

/**
 * Sherley's six hidden needs, each 0..100. Moods emerge from these (see MoodEngine).
 *
 *  energy       - physical pep; follows the time of day
 *  stimulation  - mental food; puzzles fill it, dull chat drains it
 *  company      - social fill; talking fills it, silence drains it
 *  respect      - feeling taken seriously; compliments up, dismissal down
 *  comfort      - feeling safe and warm; kindness up, conflict or user stress down
 *  confidence   - belief in her own deductions; wins up, being wrong down
 */
data class Needs(
    val energy: Float = 70f,
    val stimulation: Float = 60f,
    val company: Float = 60f,
    val respect: Float = 65f,
    val comfort: Float = 65f,
    val confidence: Float = 65f,
) {
    operator fun plus(d: NeedsDelta) = Needs(
        energy = clamp(energy + d.energy),
        stimulation = clamp(stimulation + d.stimulation),
        company = clamp(company + d.company),
        respect = clamp(respect + d.respect),
        comfort = clamp(comfort + d.comfort),
        confidence = clamp(confidence + d.confidence),
    )

    /** Short phrases for needs that are clearly low or high, used in the prompt. */
    fun describeNotable(): List<String> {
        val out = mutableListOf<String>()
        fun check(name: String, v: Float) {
            if (v < 30f) out += "low $name" else if (v > 80f) out += "high $name"
        }
        check("energy", energy)
        check("stimulation", stimulation)
        check("company", company)
        check("respect", respect)
        check("comfort", comfort)
        check("confidence", confidence)
        return out
    }

    fun toJson(): JSONObject = JSONObject()
        .put("energy", energy.toDouble())
        .put("stimulation", stimulation.toDouble())
        .put("company", company.toDouble())
        .put("respect", respect.toDouble())
        .put("comfort", comfort.toDouble())
        .put("confidence", confidence.toDouble())

    companion object {
        fun clamp(v: Float): Float = v.coerceIn(0f, 100f)

        fun fromJson(o: JSONObject?): Needs {
            if (o == null) return Needs()
            return Needs(
                energy = o.optDouble("energy", 70.0).toFloat(),
                stimulation = o.optDouble("stimulation", 60.0).toFloat(),
                company = o.optDouble("company", 60.0).toFloat(),
                respect = o.optDouble("respect", 65.0).toFloat(),
                comfort = o.optDouble("comfort", 65.0).toFloat(),
                confidence = o.optDouble("confidence", 65.0).toFloat(),
            )
        }
    }
}

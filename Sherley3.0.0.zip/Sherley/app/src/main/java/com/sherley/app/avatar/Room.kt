package com.sherley.app.avatar

import android.content.Context
import android.util.Log
import com.neethu.corelib.CameraShot
import com.neethu.corelib.ContactKind
import com.neethu.corelib.ContactPoseRequest
import com.neethu.corelib.ContactPoseResult
import com.neethu.corelib.ScenePlacement
import com.neethu.corelib.WalkBounds
import com.neethu.corelib.WalkPhase
import com.neethu.corelib.WalkStartResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.math.hypot

/**
 * Her 3D bedroom (a bundled scene with a bed, desk chair, reading chair, rug, TV...) and everything she does in it:
 * walk between spots (along the room's walkway graph so she goes around furniture), sit on the bed, the
 * desk chair, the reading chair or the rug, and lie down on the bed.
 *
 * The room, its walkway graph and its interaction points come from assets/scene/dream_bedroom.*.json.
 */
class RoomDirector(private val context: Context, private val body: AvatarBody, private val scope: CoroutineScope) {

    private class Spot(
        val id: String, val kind: String, val x: Float, val y: Float, val z: Float, val yaw: Float,
        val approach: String?, val sitIn: String?, val sitLoop: String?, val standUp: String?, val hipsLift: Float?,
    )

    private var spots: Map<String, Spot> = emptyMap()
    private var graph: Map<String, List<String>> = emptyMap()
    private var nodes: Map<String, FloatArray> = emptyMap()
    private var spawn: FloatArray? = null
    private var job: Job? = null

    var loaded = false
        private set

    /** What she is doing in the room right now, for the UI and the idle brain: "standing", "sitting" or "lying". */
    var posture: String = "standing"
        private set

    val busy: Boolean get() = job?.isActive == true

    private fun isUser(scene: String) = scene.startsWith("user_")
    private fun userFile(name: String) = java.io.File(java.io.File(context.filesDir, "rooms"), name)

    /** Built-in rooms come from assets; imported rooms from the app's own files (missing parts are allowed). */
    private fun read(scene: String, part: String): String? {
        if (isUser(scene)) return userFile("$scene.$part.json").takeIf { it.exists() }?.readText()
        return context.assets.open("scene/$scene.$part.json").bufferedReader().use { it.readText() }
    }

    private var wanderBounds: FloatArray? = null

    /** Loads the room into the 3D view. Call once the model is ready. Returns false if anything is missing. */
    fun load(scene: String = "dream_bedroom"): Boolean {
        return try {
            if (loaded) { try { body.controller.clearContactPose() } catch (_: Throwable) {} }
            posture = "standing"
            val meta = JSONObject(read(scene, "meta") ?: error("room has no meta"))
            val b = meta.optJSONObject("bounds")
            val placement = ScenePlacement(
                offsetX = meta.optDouble("offsetX", 0.0).toFloat(),
                offsetY = meta.optDouble("offsetY", 0.0).toFloat(),
                offsetZ = meta.optDouble("offsetZ", 0.0).toFloat(),
                yawDeg = meta.optDouble("yawDeg", 0.0).toFloat(),
                bounds = b?.let {
                    WalkBounds(
                        it.getDouble("minX").toFloat(), it.getDouble("maxX").toFloat(),
                        it.getDouble("minZ").toFloat(), it.getDouble("maxZ").toFloat(),
                    )
                },
            )
            b?.let { wanderBounds = floatArrayOf(it.getDouble("minX").toFloat(), it.getDouble("maxX").toFloat(), it.getDouble("minZ").toFloat(), it.getDouble("maxZ").toFloat()) }
            meta.optJSONObject("spawn")?.let {
                spawn = floatArrayOf(
                    it.getDouble("x").toFloat(), it.getDouble("y").toFloat(),
                    it.getDouble("z").toFloat(), it.optDouble("yawDeg", 0.0).toFloat(),
                )
            }

            val g = read(scene, "anchors")?.let { JSONObject(it).getJSONArray("anchors") } ?: org.json.JSONArray()
            val nodeMap = HashMap<String, FloatArray>()
            val links = HashMap<String, MutableList<String>>()
            for (i in 0 until g.length()) {
                val a = g.getJSONObject(i)
                val id = a.getString("name").lowercase()
                nodeMap[id] = floatArrayOf(a.getDouble("x").toFloat(), a.getDouble("z").toFloat())
                val l = a.optJSONArray("links")
                val list = links.getOrPut(id) { mutableListOf() }
                if (l != null) for (j in 0 until l.length()) {
                    val to = l.getString(j).lowercase()
                    list.add(to)
                    links.getOrPut(to) { mutableListOf() }.add(id) // edges are two-way
                }
            }
            nodes = nodeMap
            graph = links.mapValues { it.value.distinct() }

            val it = read(scene, "interactions")?.let { JSONObject(it).getJSONArray("anchors") } ?: org.json.JSONArray()
            val map = HashMap<String, Spot>()
            for (i in 0 until it.length()) {
                val a = it.getJSONObject(i)
                fun s(k: String): String? = a.optString(k, "").ifBlank { null }
                val id = a.getString("id").lowercase()
                map[id] = Spot(
                    id, a.optString("kind", "stand"),
                    a.optDouble("x", 0.0).toFloat(), a.optDouble("y", 0.0).toFloat(), a.optDouble("z", 0.0).toFloat(),
                    a.optDouble("yawDeg", 0.0).toFloat(),
                    s("approach")?.lowercase(), s("sitInClip"), s("sitLoopClip"), s("standUpClip"),
                    if (a.has("hipsLift")) a.getDouble("hipsLift").toFloat() else null,
                )
            }
            spots = map

            ensureWalkGaits()
            body.controller.loadScene(if (isUser(scene)) userFile("$scene.glb").absolutePath else "scene/$scene.glb", placement)
            loaded = true
            true
        } catch (e: Throwable) {
            Log.w("Room", "could not load the room", e)
            loaded = false
            false
        }
    }

    /** Puts her at the room's starting spot (after the room and model are both ready). */
    fun placeAtSpawn() {
        val s = spawn ?: return
        body.controller.setAvatarWorldPosition(s[0], s[1], s[2], s[3])
        posture = "standing"
    }

    fun unload() {
        job?.cancel()
        job = null
        try { body.controller.clearContactPose() } catch (_: Throwable) {}
        try { body.controller.removeScene() } catch (_: Throwable) {}
        loaded = false
        posture = "standing"
    }

    private fun ensureWalkGaits() {
        val c = body.controller
        if (c.isWalkGaitConfigured()) return
        if (!c.setWalkGait("vrmas/walk.vrma", 1.3f)) c.setWalkGait("animations/Female Normal Walk.vrma", 1.22f)
        c.setRunGait("animations/Running Forward.vrma")
        c.setStrafeGaits("animations/Walking Strafe To The Left.vrma", "animations/Walking Strafe To The Right.vrma")
    }

    /** True if [id] is a place she knows. */
    fun knows(id: String) = spots.containsKey(id)

    /** Start doing something at a spot (walk there, then sit, lie or just stand). Runs in the background. */
    fun go(wanted: String) {
        // Rooms name their spots differently; use the nearest equivalent one that exists in this room.
        val alternatives = mapOf(
            "rug_meditate" to listOf("meditation_seat", "window_seat", "tea_seat"),
            "reading_seat" to listOf("tea_seat", "window_seat", "meditation_seat"),
            "tv_approach" to listOf("telescope_approach", "altar_approach", "window_view"),
            "rug_watch_tv" to listOf("tv_approach", "window_view", "spawn"),
            "game_approach" to listOf("sword_approach", "tea_approach", "spawn"),
            "yoga_spot" to listOf("rug_meditate", "meditation_approach", "spawn"),
        )
        val spotId = (listOf(wanted) + alternatives[wanted].orEmpty()).firstOrNull { spots.containsKey(it) } ?: return
        val spot = spots[spotId] ?: return
        if (!loaded) return
        job?.cancel()
        job = scope.launch {
            try { run(spot) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Throwable) { Log.w("Room", "go($spotId) failed", e) }
        }
    }

    /** Walk to a random free point in the room (works in any room, including imported ones). */
    fun wander() {
        val b = wanderBounds ?: return
        if (!loaded) return
        job?.cancel()
        job = scope.launch {
            try {
                if (body.controller.getContactPoseState() != null) { body.controller.clearContactPose(); delay(1_400) }
                posture = "standing"
                val x = b[0] + 0.3f + kotlin.random.Random.nextFloat() * (b[1] - b[0] - 0.6f).coerceAtLeast(0.1f)
                val z = b[2] + 0.3f + kotlin.random.Random.nextFloat() * (b[3] - b[2] - 0.6f).coerceAtLeast(0.1f)
                walkTo(x, z)
            } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Throwable) { Log.w("Room", "wander failed", e) }
        }
    }

    /** Get up from the bed or a chair. */
    fun standUp() {
        if (!loaded) return
        job?.cancel()
        job = scope.launch {
            if (body.controller.getContactPoseState() != null) {
                body.controller.clearContactPose()
                delay(1_400)
            }
            posture = "standing"
        }
    }

    private suspend fun run(spot: Spot) {
        val c = body.controller
        // 1. Stand up first if she is sitting or lying.
        if (c.getContactPoseState() != null) {
            c.clearContactPose()
            delay(1_400)
        }
        posture = "standing"

        // 2. Walk: sitting and lying spots are reached from their approach point.
        val contact = spot.kind == "sit" || spot.kind == "lie"
        val targetId = if (contact) spot.approach ?: spot.id else spot.id
        val target = nodes[targetId]?.let { it } ?: floatArrayOf(spot.x, spot.z)
        for (p in route(targetId, target)) {
            if (!walkTo(p[0], p[1])) break
        }

        // 3. Face the right way.
        if (!contact && spot.kind != "waypoint") {
            c.turnTo(spot.yaw)
            delay(900)
        }

        // 4. Sit or lie.
        if (contact) {
            val result = c.applyContactPose(
                ContactPoseRequest(
                    kind = if (spot.kind == "lie") ContactKind.LIE else ContactKind.SIT,
                    x = spot.x, y = spot.y, z = spot.z, yawDeg = spot.yaw,
                    sitInClipAssetPath = spot.sitIn,
                    sitLoopClipAssetPath = spot.sitLoop,
                    standUpClipAssetPath = spot.standUp,
                    hipsLiftMeters = spot.hipsLift ?: 0.09f,
                ),
            )
            if (result == ContactPoseResult.STARTED) posture = if (spot.kind == "lie") "lying" else "sitting"
        }
    }

    /** The list of points to walk through to reach [targetId]: nearest walkway node, then along the graph. */
    private fun route(targetId: String, target: FloatArray): List<FloatArray> {
        val pos = FloatArray(3)
        if (!body.controller.avatarWorldPos(pos) || graph.isEmpty()) return listOf(target)
        val start = nodes.minByOrNull { hypot(it.value[0] - pos[0], it.value[1] - pos[2]) }?.key ?: return listOf(target)
        val goal = if (graph.containsKey(targetId)) targetId else nodes.minByOrNull { hypot(it.value[0] - target[0], it.value[1] - target[1]) }?.key
            ?: return listOf(target)
        // Breadth-first search over the walkway graph.
        val prev = HashMap<String, String?>()
        prev[start] = null
        val queue = ArrayDeque(listOf(start))
        while (queue.isNotEmpty() && !prev.containsKey(goal)) {
            val cur = queue.removeFirst()
            for (n in graph[cur].orEmpty()) if (!prev.containsKey(n)) { prev[n] = cur; queue.addLast(n) }
        }
        if (!prev.containsKey(goal)) return listOf(target)
        val path = ArrayList<String>()
        var at: String? = goal
        while (at != null) { path.add(at); at = prev[at] }
        path.reverse()
        val pts = path.mapNotNull { nodes[it] }.toMutableList()
        if (target[0] != pts.lastOrNull()?.get(0) || target[1] != pts.lastOrNull()?.get(1)) pts.add(target)
        return pts
    }

    /** Walks in a straight line to (x, z) and waits until she arrives. False if it could not start or took too long. */
    private suspend fun walkTo(x: Float, z: Float): Boolean {
        val c = body.controller
        val pos = FloatArray(3)
        if (c.avatarWorldPos(pos) && hypot(pos[0] - x, pos[2] - z) < 0.15f) return true
        val r = c.startWalk(x, z, 1.0f)
        if (r != WalkStartResult.STARTED) return false
        delay(300)
        val deadline = System.currentTimeMillis() + 45_000
        var still = 0
        while (System.currentTimeMillis() < deadline) {
            still = if (c.getWalkState()?.phase == WalkPhase.IDLE) still + 1 else 0
            if (still >= 2) return true
            delay(120)
        }
        c.stopWalk()
        return false
    }
}

package com.sherley.app.companion

/** Fallback when the language model gave no emotion tag: derive one of the 9 voice emotions from her mood. */
object EmotionMap {
    fun forMood(m: Mood): String = when (m) {
        Mood.HAPPY, Mood.CHEERFUL, Mood.DELIGHTED, Mood.PLAYFUL, Mood.PROUD, Mood.AFFECTIONATE -> "happy"
        Mood.GIDDY, Mood.EXCITED, Mood.EAGER, Mood.HYPER -> "excited"
        Mood.MISCHIEVOUS, Mood.COCKY, Mood.SASSY, Mood.JEALOUS -> "sarcastic"
        Mood.CURIOUS, Mood.INTRIGUED, Mood.SCHEMING, Mood.SUSPICIOUS, Mood.THOUGHTFUL, Mood.DETERMINED -> "curious"
        Mood.RELAXED, Mood.CONTENT, Mood.COZY, Mood.DREAMY, Mood.NOSTALGIC -> "calm"
        Mood.BORED, Mood.SLEEPY, Mood.LAZY, Mood.TIRED, Mood.DISTRACTED -> "sleepy"
        Mood.SAD, Mood.LONELY, Mood.DISAPPOINTED, Mood.HOMESICK -> "sad"
        Mood.ANNOYED, Mood.GRUMPY, Mood.FRUSTRATED, Mood.STUBBORN, Mood.SULKY -> "angry"
        Mood.EMBARRASSED, Mood.SHY, Mood.WORRIED, Mood.NERVOUS -> "shy"
    }
}

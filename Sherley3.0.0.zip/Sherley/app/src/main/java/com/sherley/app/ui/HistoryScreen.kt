package com.sherley.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sherley.app.config.AppConfig
import com.sherley.app.data.MessageEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The full conversation, oldest to newest. Tap one of Sherley's messages to open it as a case file. */
@Composable
fun HistoryScreen(vm: ChatViewModel, onOpenClue: (Long) -> Unit, onBack: () -> Unit) {
    val messages by vm.history.collectAsStateWithLifecycle(initialValue = emptyList())
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.scrollToItem(messages.lastIndex)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing),
    ) {
        TextButton(onClick = onBack) { Text("← Back", fontSize = 16.sp) }
        Text(
            text = "History",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (messages.isEmpty()) {
                item { Text("Nothing here yet. Say something to Sherley.") }
            }
            items(messages, key = { it.id }) { message ->
                MessageRow(message, vm.settings.userName, onOpenClue)
            }
        }
    }
}

@Composable
private fun MessageRow(message: MessageEntity, userName: String, onOpenClue: (Long) -> Unit) {
    val fromUser = message.role == "user"
    val time = SimpleDateFormat("d MMM HH:mm", Locale.ENGLISH).format(Date(message.timestamp))
    Surface(
        color = if (fromUser) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !fromUser) { onOpenClue(message.id) },
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(
                text = (if (fromUser) userName else AppConfig.NICKNAME) + " · " + time,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
            )
            Text(text = message.text, fontSize = 16.sp)
        }
    }
}

package com.sherley.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sherley.app.avatar.AvatarBody
import com.sherley.app.avatar.BodyLayouts
import com.sherley.app.avatar.JointCalibration
import com.sherley.app.avatar.Pose
import com.sherley.app.avatar.PoseController
import com.sherley.app.avatar.AvatarScene
import com.sherley.app.avatar.TouchLayer
import com.sherley.app.config.AppConfig
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private val ReplyStyle = TextStyle(fontSize = 18.sp, lineHeight = 26.sp, color = Color.White)

/**
 * The home screen, built in layers (bottom to top):
 *   1. mood background image   2. the 3D avatar   3. invisible touch layer   4. widgets (bubble, input, bar)
 * Widgets can be hidden (hideUi) to see only her.
 */
@Composable
fun MainScreen(
    vm: ChatViewModel,
    hideUi: Boolean,
    onToggleUi: () -> Unit,
    onOpenClue: (Long) -> Unit,
    onHistory: () -> Unit,
    onBackgrounds: () -> Unit,
    onSettings: () -> Unit,
    onApps: () -> Unit,
    onImport: () -> Unit,
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val bgVersion by vm.backgrounds.version.collectAsStateWithLifecycle()
    val settings = vm.settings
    val avatarOn = settings.avatarEnabled
    var body by remember { mutableStateOf<AvatarBody?>(null) }
    val pose = remember {
        PoseController(Pose.fromJson(settings.poseJson)) { settings.poseJson = it?.toJson().orEmpty() }
    }
    var cameraMode by remember { mutableStateOf(settings.cameraMode) }
    var cameraNonce by remember { mutableStateOf(0) }
    val voiceWorking by vm.voice.working.collectAsStateWithLifecycle()
    var roomTick by remember { mutableStateOf(0) }
    var calibration by remember {
        val c = JointCalibration.fromJson(settings.calibrationJson)
        Pose.applyCalibration(c)
        mutableStateOf(c)
    }
    val minRadiusPx = with(LocalDensity.current) { 26.dp.toPx() }
    val layoutOf = { w: Float, h: Float -> body?.let { BodyLayouts.compute(it, pose.displayPose(), w, h, minRadiusPx, calibration) } }

    // A new touch reaction: play its arm/head gesture (the face flash is handled by the avatar driver).
    LaunchedEffect(ui.reactionNonce) {
        val r = ui.reaction
        if (r != null && ui.reactionNonce > 0) pose.play(r.steps(ui.reactionSide))
    }

    // Time may have passed while the app was in the background.
    LifecycleResumeEffect(Unit) {
        vm.refreshMood()
        onPauseOrDispose { }
    }
    // Every few seconds she may speak up after a quiet while.
    LaunchedEffect(Unit) {
        while (true) {
            delay(5_000)
            vm.idleTick()
        }
    }

    BoxWithConstraints(
        Modifier.fillMaxSize().background(
            androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFF3B2A7A), Color(0xFF2B5BA8), Color(0xFF1F9AA8))),
        ),
    ) {
        val density = LocalDensity.current
        val viewportHeightPx = with(density) { maxHeight.toPx() }
        // Text width = bubble width (screen - 32 outer padding) - 32 card padding
        val replyTextWidthPx = with(density) { (maxWidth - 64.dp).roundToPx() }

        // Layer 1: mood background (hidden behind the avatar unless you turned that on in Settings)
        if (!avatarOn || settings.bgBehindAvatar) {
            val bgFile = remember(ui.mood, bgVersion) { vm.backgrounds.fileFor(ui.mood) }
            MoodBackground(file = bgFile, mood = ui.mood)
        }

        // Layers 2 + 3: the body and the touch layer. One finger touches her; two fingers orbit/zoom the
        // camera, three fingers move it (handled inside the touch layer).
        if (avatarOn) {
            AvatarScene(
                version = ui.avatarVersion,
                mood = ui.mood,
                intensity = ui.intensity,
                speaking = ui.speaking,
                flash = ui.reaction?.face,
                flashKey = ui.reactionNonce,
                pose = pose,
                faceStrength = settings.faceStrength,
                devMode = settings.devMode,
                renderMode = settings.renderMode,
                quality = settings.quality,
                lightLevel = settings.lightLevel,
                roomEnabled = settings.roomEnabled,
                roomScene = settings.roomScene.also { roomTick },
                cameraMode = cameraMode,
                cameraNonce = cameraNonce,
                roomYaw = settings.roomYaw,
                action = ui.action,
                actionNonce = ui.actionNonce,
                modifier = Modifier.fillMaxSize(),
                onBody = { body = it },
            )
            if (!ui.calibrating) {
                TouchLayer(
                    layoutProvider = layoutOf,
                    poseActive = pose.editing != null,
                    onTouch = vm::touch,
                    onJointLongPress = { pose.beginEdit(it) },
                    onPoseDrag = { pt, layout ->
                        val joint = pose.editJoint
                        val b = body
                        if (joint != null && b != null) BodyLayouts.aim(b, joint, layout, pt)?.let { pose.aimJoint(it) }
                    },
                    onLook = if (settings.eyeFollow) ({ x: Float, y: Float -> body?.lookAtScreen(x, y) }) else null,
                    onOrbit = { dx, dy -> body?.orbit(dx, dy) },
                    onZoom = { d -> body?.zoom(d) },
                    onPan = { dx, dy -> body?.pan(dx, dy) },
                )
            }
            if (settings.devMode) {
                // Yellow dots = where the app thinks her joints are (head, neck, shoulders, elbows, wrists, hands)
                var tick by remember { mutableIntStateOf(0) }
                LaunchedEffect(Unit) { while (true) { delay(120); tick++ } }
                Canvas(Modifier.fillMaxSize()) {
                    tick.hashCode()
                    layoutOf(size.width, size.height)?.points?.values?.forEach {
                        drawCircle(Color.Yellow, 9f, Offset(it.x, it.y))
                    }
                }
            }
        }

        // Layer 4: widgets
        if (avatarOn && ui.calibrating) {
            LaunchedEffect(Unit) { pose.natural() }
            JointCalibrator(
                body = body,
                minRadiusPx = minRadiusPx,
                onSave = { c ->
                    settings.calibrationJson = c.toJson()
                    Pose.applyCalibration(c)
                    calibration = c
                    vm.setCalibrating(false)
                },
                onReset = {
                    settings.calibrationJson = ""
                    Pose.applyCalibration(null)
                    calibration = null
                    vm.setCalibrating(false)
                },
                onCancel = { vm.setCalibrating(false) },
            )
        }

        if (!hideUi && !ui.calibrating) {
            Column(
                Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(16.dp),
            ) {
                TopBar(
                    moodLabel = "${ui.mood.label} · ${(ui.intensity * 100).roundToInt()}%",
                    hasSavedPose = pose.saved != null,
                    voiceOn = settings.voiceEnabled,
                    voiceWorking = voiceWorking,
                    cameraMode = cameraMode,
                    roomOn = settings.roomEnabled,
                    onApps = onApps,
                    onHide = onToggleUi,
                    onSettings = onSettings,
                    onHistory = onHistory,
                    onBackgrounds = onBackgrounds,
                    onImport = onImport,
                    onResetPose = pose::natural,
                    onCalibrate = { vm.setCalibrating(true) },
                    onVoice = { settings.voiceEnabled = !settings.voiceEnabled; if (!settings.voiceEnabled) vm.voice.stop() },
                    onCameraMode = { m -> settings.cameraMode = m; cameraMode = m; cameraNonce++ },
                    onResetCamera = { cameraNonce++ },
                    onRoomToggle = { settings.roomEnabled = !settings.roomEnabled; roomTick++ },
                    onAction = { key ->
                        if (key == "next_room") {
                            val rooms = settings.allRooms().map { it.first }
                            settings.roomScene = rooms[(rooms.indexOf(settings.roomScene) + 1) % rooms.size]
                            roomTick++
                        } else vm.requestAction(key)
                    },
                )
                if (pose.editing != null) PoseBar(pose)
                ui.error?.let { message ->
                    Spacer(Modifier.height(10.dp))
                    Surface(
                        color = Color(0xCC5A1D1D),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().clickable { vm.dismissError() },
                    ) {
                        Text(
                            text = "$message  (tap to dismiss)",
                            color = Color.White,
                            modifier = Modifier.padding(12.dp),
                        )
                    }
                }
            }

            val hideText = settings.voiceEnabled && voiceWorking && !settings.textWithVoice
            if (hideText) {
                // Her voice is working, so the speech bubble is not needed. Keep a small "thinking" hint.
                if (ui.thinking) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.35f),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.align(Alignment.TopCenter).windowInsetsPadding(WindowInsets.safeDrawing).padding(top = 64.dp),
                    ) {
                        Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                            Spacer(Modifier.size(8.dp))
                            Text("Thinking…", color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            } else DraggableBubble(
                vm = vm,
                text = ui.reflex ?: ui.latest?.text ?: welcomeText(vm),
                messageId = if (ui.reflex == null) ui.latest?.id else null,
                viewportHeightPx = viewportHeightPx,
                textWidthPx = replyTextWidthPx,
                thinking = ui.thinking,
                onOpenClue = onOpenClue,
            )

            DraggableInput(
                vm = vm,
                enabled = !ui.thinking,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(16.dp),
            )
        } else if (!ui.calibrating) {
            // Tiny button to bring the widgets back
            Text(
                text = "◐",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 26.sp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(16.dp)
                    .clickable { onToggleUi() },
            )
        }
    }
}

private fun welcomeText(vm: ChatViewModel): String {
    val name = vm.settings.userName
    return "Well, well. $name arrives. What mystery are we cracking today?"
}

/**
 * The header is just two round buttons: apps on the left, and one menu on the right that holds everything
 * else (sections open and close inside the menu).
 */
@Composable
private fun TopBar(
    moodLabel: String,
    hasSavedPose: Boolean,
    voiceOn: Boolean,
    voiceWorking: Boolean,
    cameraMode: String,
    roomOn: Boolean,
    onApps: () -> Unit,
    onHide: () -> Unit,
    onSettings: () -> Unit,
    onHistory: () -> Unit,
    onBackgrounds: () -> Unit,
    onImport: () -> Unit,
    onResetPose: () -> Unit,
    onCalibrate: () -> Unit,
    onVoice: () -> Unit,
    onCameraMode: (String) -> Unit,
    onResetCamera: () -> Unit,
    onRoomToggle: () -> Unit,
    onAction: (String) -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    var section by remember { mutableStateOf<String?>(null) }

    @Composable
    fun header(key: String, label: String) {
        DropdownMenuItem(
            text = { Text(label + if (section == key) "  ▴" else "  ▾", fontWeight = FontWeight.SemiBold) },
            onClick = { section = if (section == key) null else key },
        )
    }

    @Composable
    fun item(label: String, indent: Boolean = false, onClick: () -> Unit) {
        DropdownMenuItem(
            text = { Text(label, modifier = Modifier.padding(start = if (indent) 14.dp else 0.dp)) },
            onClick = { menu = false; section = null; onClick() },
        )
    }

    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        RoundButton("▦", onApps)
        Spacer(Modifier.weight(1f))
        Box {
            RoundButton("☰") { menu = true }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false; section = null }) {
                Text(moodLabel, fontSize = 13.sp, color = Color.Gray, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                item("History", onClick = onHistory)
                item("Backgrounds", onClick = onBackgrounds)
                item("Import room or model…", onClick = onImport)
                item(if (!voiceOn) "Voice: off" else if (voiceWorking) "Voice: on" else "Voice: on (not available)", onClick = onVoice)

                header("actions", "Actions")
                if (section == "actions") for ((label, key) in listOf(
                    "Sit at the desk" to "room:desk_seat", "Sit in the reading chair" to "room:reading_seat",
                    "Sit on the bed" to "room:bed_sit", "Lie on the bed" to "room:bed_lie", "Sit on the rug" to "room:rug_meditate",
                    "Go to the window" to "room:window_view", "Go to the TV" to "room:tv_approach", "Stand up" to "stand",
                    "Wave" to "wave", "Stretch" to "stretch", "Look around" to "look_around", "Cheer" to "cheer", "Act shy" to "shy",
                )) item(label, indent = true) { onAction(key) }

                header("room", "Room")
                if (section == "room") {
                    item(if (roomOn) "Room: on (tap to turn off)" else "Room: off (tap to turn on)", indent = true, onClick = onRoomToggle)
                    item("Next room", indent = true) { onAction("next_room") }
                }

                header("camera", "Camera")
                if (section == "camera") {
                    for ((label, key) in listOf("Auto (follows her)" to "auto", "Close-up" to "close", "Half body" to "medium", "Full body" to "full", "Wide" to "wide")) {
                        item((if (cameraMode == key) "● " else "") + label, indent = true) { onCameraMode(key) }
                    }
                    item("Reset camera", indent = true, onClick = onResetCamera)
                    Text(
                        "Two fingers: turn and zoom. Three fingers: move.",
                        fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(horizontal = 30.dp, vertical = 4.dp),
                    )
                }

                header("pose", "Pose and joints")
                if (section == "pose") {
                    if (hasSavedPose) item("Reset pose to natural", indent = true, onClick = onResetPose)
                    item("Calibrate joints", indent = true, onClick = onCalibrate)
                }

                item("Hide interface", onClick = onHide)
                item("Settings", onClick = onSettings)
            }
        }
    }
}

@Composable
private fun RoundButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.35f)).clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = 22.sp, color = Color.White) }
}

/** Shown while you are posing a joint: keep the pose or throw it away. */
@Composable
private fun PoseBar(pose: PoseController) {
    Surface(
        color = Color(0xFF1B2A55).copy(alpha = 0.88f),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(
                text = "Posing her ${pose.editJoint?.label ?: "pose"}. Drag anywhere to aim it, or long-press another joint to switch.",
                color = Color.White,
                fontSize = 13.sp,
            )
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = pose::save) { Text("Save pose") }
                OutlinedButton(onClick = pose::discard) { Text("Discard", color = Color.White) }
                OutlinedButton(onClick = pose::natural) { Text("Natural", color = Color.White) }
            }
        }
    }
}

/**
 * The speech bubble: a draggable widget. Shows her text, unless it would fill more than half of the
 * screen height. Then a clue icon is shown instead and the full text opens on its own page.
 * Drag the dots to move it; double-tap them to put it back.
 */
@Composable
private fun DraggableBubble(
    vm: ChatViewModel,
    text: String,
    messageId: Long?,
    viewportHeightPx: Float,
    textWidthPx: Int,
    thinking: Boolean,
    onOpenClue: (Long) -> Unit,
) {
    var offset by remember { mutableStateOf(Offset(vm.settings.bubbleOffsetX, vm.settings.bubbleOffsetY)) }
    val measurer = rememberTextMeasurer()
    val isLong = remember(text, textWidthPx, viewportHeightPx) {
        val laidOut = measurer.measure(
            text = text,
            style = ReplyStyle,
            constraints = Constraints(maxWidth = textWidthPx),
        )
        laidOut.size.height > viewportHeightPx * AppConfig.LONG_REPLY_VIEWPORT_FRACTION
    }

    Surface(
        color = Color(0xFF1B2A55).copy(alpha = 0.55f),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(start = 16.dp, end = 16.dp, top = 72.dp)
            .offset { IntOffset(offset.x.roundToInt(), offset.y.roundToInt()) }
            .fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                text = "⠿",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 20.sp,
                modifier = Modifier
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragEnd = { vm.saveBubbleOffset(offset.x, offset.y) },
                        ) { change, drag ->
                            change.consume()
                            offset += drag
                        }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures(onDoubleTap = {
                            offset = Offset.Zero
                            vm.saveBubbleOffset(0f, 0f)
                        })
                    },
            )
            when {
                thinking -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = Color.White,
                    )
                    Spacer(Modifier.size(12.dp))
                    Text(text = "Thinking…", style = ReplyStyle)
                }

                isLong && messageId != null -> Row(
                    modifier = Modifier.fillMaxWidth().clickable { onOpenClue(messageId) },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Open clue",
                        tint = Color(0xFFE0B25A),
                        modifier = Modifier.size(36.dp),
                    )
                    Spacer(Modifier.size(12.dp))
                    Text(text = "I found a clue. Tap to read the full case file.", style = ReplyStyle)
                }

                else -> Text(text = text, style = ReplyStyle)
            }
        }
    }
}

/**
 * The see-through text box. Drag the dots to move it anywhere; double-tap them to put it back.
 * Its position is remembered between launches.
 */
@Composable
private fun DraggableInput(vm: ChatViewModel, enabled: Boolean, modifier: Modifier = Modifier) {
    var offset by remember { mutableStateOf(Offset(vm.settings.inputOffsetX, vm.settings.inputOffsetY)) }
    var draft by remember { mutableStateOf("") }

    fun submit() {
        if (draft.isNotBlank() && enabled) {
            vm.send(draft)
            draft = ""
        }
    }

    Row(
        modifier = modifier
            .offset { IntOffset(offset.x.roundToInt(), offset.y.roundToInt()) }
            .fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Drag handle
        Text(
            text = "⠿",
            color = Color.White,
            fontSize = 26.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .size(40.dp)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragEnd = { vm.saveInputOffset(offset.x, offset.y) },
                    ) { change, drag ->
                        change.consume()
                        offset += drag
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = {
                        offset = Offset.Zero
                        vm.saveInputOffset(0f, 0f)
                    })
                },
        )

        OutlinedTextField(
            value = draft,
            onValueChange = { draft = it },
            modifier = Modifier.weight(1f),
            placeholder = { Text("Tell Sherley…", color = Color.White.copy(alpha = 0.6f)) },
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
            shape = RoundedCornerShape(24.dp),
            maxLines = 4,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { submit() }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.Black.copy(alpha = AppConfig.INPUT_BG_ALPHA),
                unfocusedContainerColor = Color.Black.copy(alpha = AppConfig.INPUT_BG_ALPHA),
                focusedBorderColor = Color.White.copy(alpha = 0.7f),
                unfocusedBorderColor = Color.White.copy(alpha = 0.4f),
                cursorColor = Color.White,
            ),
        )

        IconButton(
            onClick = ::submit,
            enabled = enabled && draft.isNotBlank(),
            modifier = Modifier
                .size(44.dp)
                .background(Color.Black.copy(alpha = 0.35f), CircleShape),
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Send,
                contentDescription = "Send",
                tint = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

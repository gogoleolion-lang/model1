package com.sherley.app.avatar

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import com.sherley.app.config.AppConfig
import kotlin.math.hypot

/**
 * An invisible layer that turns finger movement into "she was touched here".
 *
 *  - tap / double tap / stroke on a body part  -> onTouch (she reacts)
 *  - long press on a joint                     -> onJointLongPress (starts pose editing)
 *  - while poseActive, dragging aims the joint -> onPoseDrag
 *
 * Camera gestures use more than one finger, so they never clash with touching her:
 *  - two fingers moving together -> orbit around her (left/right/up/down)
 *  - two fingers pinching        -> zoom
 *  - three fingers moving        -> move the camera sideways / up / down
 */
@Composable
fun TouchLayer(
    layoutProvider: (width: Float, height: Float) -> BodyLayout?,
    poseActive: Boolean,
    onTouch: (TouchKind, Region) -> Unit,
    onJointLongPress: (Joint) -> Unit,
    onPoseDrag: (Pt, BodyLayout) -> Unit,
    onLook: ((Float, Float) -> Unit)? = null,
    onOrbit: (Float, Float) -> Unit = { _, _ -> },
    onZoom: (Float) -> Unit = {},
    onPan: (Float, Float) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier,
) {
    val orbitNow by rememberUpdatedState(onOrbit)
    val zoomNow by rememberUpdatedState(onZoom)
    val panNow by rememberUpdatedState(onPan)
    var size by remember { mutableStateOf(IntSize.Zero) }
    val layoutNow by rememberUpdatedState(layoutProvider)
    val activeNow by rememberUpdatedState(poseActive)
    val touchNow by rememberUpdatedState(onTouch)
    val longNow by rememberUpdatedState(onJointLongPress)
    val dragNow by rememberUpdatedState(onPoseDrag)
    val lookNow by rememberUpdatedState(onLook)

    fun layout(): BodyLayout? =
        if (size.width == 0) null else layoutNow(size.width.toFloat(), size.height.toFloat())

    fun regionAt(o: Offset): Region? = layout()?.regionAt(Pt(o.x, o.y))

    Box(
        modifier
            .fillMaxSize()
            .onSizeChanged { size = it }
            .pointerInput(Unit) {
                // Camera gestures: watched first (Initial pass); once a second finger lands, this takes the
                // whole gesture so the touch handlers below see it as cancelled.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    var multi = false
                    var lastCentroid: Offset? = null
                    var lastSpan = 0f
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val down = event.changes.filter { it.pressed }
                        if (down.size >= 2) {
                            multi = true
                            val centroid = Offset(down.sumOf { it.position.x.toDouble() }.toFloat() / down.size,
                                down.sumOf { it.position.y.toDouble() }.toFloat() / down.size)
                            val span = down.map { (it.position - centroid).getDistance() }.average().toFloat() * 2f
                            val lc = lastCentroid
                            if (lc != null) {
                                val d = centroid - lc
                                val ds = span - lastSpan
                                when {
                                    down.size >= 3 -> panNow(d.x, d.y)
                                    kotlin.math.abs(ds) > 2f * hypot(d.x, d.y) -> zoomNow(ds * 1.6f)
                                    else -> orbitNow(d.x, d.y)
                                }
                            }
                            lastCentroid = centroid
                            lastSpan = span
                        } else {
                            lastCentroid = null
                        }
                        if (multi) event.changes.forEach { it.consume() }
                    } while (event.changes.any { it.pressed })
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { o -> if (!activeNow) regionAt(o)?.let { touchNow(TouchKind.TAP, it) } },
                    onDoubleTap = { o -> if (!activeNow) regionAt(o)?.let { touchNow(TouchKind.DOUBLE_TAP, it) } },
                    onLongPress = { o -> layout()?.jointAt(Pt(o.x, o.y))?.let { longNow(it) } },
                )
            }
            .pointerInput(Unit) {
                var travelled = 0f
                var startRegion: Region? = null
                detectDragGestures(
                    onDragStart = { o -> travelled = 0f; startRegion = if (activeNow) null else regionAt(o) },
                    onDrag = { change, delta ->
                        if (activeNow) {
                            change.consume()
                            layout()?.let { dragNow(Pt(change.position.x, change.position.y), it) }
                        } else {
                            travelled += hypot(delta.x, delta.y)
                            if (size.width > 0) {
                                lookNow?.invoke(
                                    (change.position.x / size.width * 2f - 1f).coerceIn(-1f, 1f),
                                    (change.position.y / size.height * 2f - 1f).coerceIn(-1f, 1f),
                                )
                            }
                        }
                    },
                    onDragEnd = {
                        val enough = size.width > 0 && travelled >= AppConfig.STROKE_MIN_FRACTION * size.width * 0.5f
                        val r = startRegion
                        if (!activeNow && enough && r != null) touchNow(TouchKind.STROKE, r)
                    },
                    onDragCancel = {},
                )
            },
    )
}

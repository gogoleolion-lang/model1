package com.sherley.app.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice as TtsVoice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

/**
 * Sherley's voice, using the phone's own text-to-speech engine (works offline when an English voice is installed).
 *
 * [working] is true once the engine started and has an English voice, and turns false again if speaking fails.
 * The main screen hides the speech bubble only while [working] is true, so you never lose her words.
 */
class Voice(context: Context) {

    private val app = context.applicationContext
    private var tts: TextToSpeech? = null
    private var counter = 0

    private val _working = MutableStateFlow(false)
    val working: StateFlow<Boolean> = _working

    private val _voiceName = MutableStateFlow("")
    /** The voice in use, for the Settings screen. */
    val voiceName: StateFlow<String> = _voiceName

    /** Called with true when she starts speaking and false when she stops. */
    var onSpeaking: ((Boolean) -> Unit)? = null

    var pitch = 1.2f
    var rate = 1.05f
    /** Name of the voice the user picked, or blank for the best automatic one. */
    var preferredVoice = ""

    private var voices: List<TtsVoice> = emptyList()

    // Preferred engine: HayaiTTS (Kokoro, zf_xiaoyi, with emotion). Falls back to the phone's voice on any failure.
    private val hayai = HayaiClient(app)
    @Volatile private var hayaiOk = false
    @Volatile private var hayaiTried = false

    private val _hayaiStatus = MutableStateFlow("HayaiTTS: not checked yet")
    /** What the HayaiTTS connection is doing, for the Settings screen. */
    val hayaiStatus: StateFlow<String> = _hayaiStatus

    private fun checkHayai() {
        if (hayaiTried) return
        hayaiTried = true
        kotlin.concurrent.thread(isDaemon = true) {
            _hayaiStatus.value = "HayaiTTS: starting it…"
            val why = hayai.wake()
            if (why != null) { _hayaiStatus.value = "HayaiTTS: $why. Using the phone's own voice."; hayaiTried = false; return@thread }
            // The service needs a moment to load the model after waking.
            for (i in 0 until 60) {
                _hayaiStatus.value = "HayaiTTS: waiting for it to answer (try ${i + 1}/60; the first start loads the voice and can take a minute)…"
                if (hayai.alive()) {
                    hayaiOk = true; _voiceName.value = "HayaiTTS · zf_xiaoyi"; _working.value = true
                    _hayaiStatus.value = "HayaiTTS: ready (Kokoro, zf_xiaoyi, with emotion)"
                    return@thread
                }
                try { Thread.sleep(2000) } catch (_: InterruptedException) { return@thread }
            }
            _hayaiStatus.value = "HayaiTTS: started but did not answer on 127.0.0.1:11435. Is the Kokoro voice installed in HayaiTTS, and is battery saving / autostart allowed for it? Using the phone's own voice."
            hayaiTried = false
        }
    }

    /** Settings > "Retry HayaiTTS". */
    fun retryHayai() { hayaiOk = false; hayaiTried = false; checkHayai() }

    init {
        hayai.onFailure = { why ->
            hayaiOk = false; hayaiTried = false
            _hayaiStatus.value = "HayaiTTS failed: $why. Using the phone's own voice until you tap Retry."
            kotlin.concurrent.thread(isDaemon = true) {
                try { Thread.sleep(4000) } catch (_: InterruptedException) { return@thread }
                val more = hayai.diagnose()
                if (more.isNotBlank()) _hayaiStatus.value = "HayaiTTS failed: $why. Details: $more. Using the phone's own voice until you tap Retry."
            }
        }
        hayai.onSpeaking = { on -> onSpeaking?.invoke(on) }
        checkHayai()
        try {
            tts = TextToSpeech(app) { status ->
                val engine = tts
                if (status != TextToSpeech.SUCCESS || engine == null) {
                    _working.value = hayaiOk
                    return@TextToSpeech
                }
                val lang = engine.setLanguage(Locale.US)
                if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                    _working.value = hayaiOk
                    return@TextToSpeech
                }
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { onSpeaking?.invoke(true) }
                    override fun onDone(utteranceId: String?) { if (utteranceId == lastId) onSpeaking?.invoke(false) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { failed() }
                    override fun onError(utteranceId: String?, errorCode: Int) { failed() }
                })
                voices = try {
                    engine.voices.orEmpty()
                        .filter { it.locale.language == "en" && !it.isNetworkConnectionRequired }
                        .sortedWith(compareByDescending<TtsVoice> { score(it) }.thenBy { it.name })
                } catch (_: Throwable) {
                    emptyList()
                }
                applyVoice()
                _working.value = true
            }
        } catch (_: Throwable) {
            _working.value = hayaiOk
        }
    }

    @Volatile private var lastId = ""

    private fun failed() {
        _working.value = hayaiOk
        onSpeaking?.invoke(false)
    }

    /** Prefers female-sounding, higher-quality, US/UK English voices. */
    private fun score(v: TtsVoice): Int {
        val n = v.name.lowercase()
        var s = v.quality / 100
        if (n.contains("female") || n.contains("-f-") || n.contains("#female")) s += 6
        if (n.contains("male") && !n.contains("female")) s -= 6
        if (v.locale.country == "US" || v.locale.country == "GB") s += 2
        return s
    }

    private fun applyVoice() {
        val engine = tts ?: return
        val pick = voices.firstOrNull { it.name == preferredVoice } ?: voices.firstOrNull()
        if (pick != null) {
            try { engine.voice = pick } catch (_: Throwable) {}
            _voiceName.value = pick.name
        }
    }

    /** Switches to the next installed voice and says a sample. Returns its name. */
    fun nextVoice(): String {
        if (voices.isEmpty()) return ""
        val i = voices.indexOfFirst { it.name == _voiceName.value }
        preferredVoice = voices[(i + 1) % voices.size].name
        applyVoice()
        speak("Hello! I am Sherley. How do I sound?")
        return preferredVoice
    }

    /** Says [text]. Returns false if the engine is not usable (the caller then shows the text instead). */
    fun speak(text: String, emotion: String = "calm", intensity: Int = 2): Boolean {
        if (hayaiOk) {
            val clean = clean(text)
            if (clean.isBlank()) return true
            hayai.speak(clean, emotion, intensity)
            return true
        }
        val engine = tts ?: return false
        if (!_working.value) return false
        val clean = clean(text)
        if (clean.isBlank()) return true
        applyVoice()
        engine.setPitch(pitch.coerceIn(0.5f, 2f))
        engine.setSpeechRate(rate.coerceIn(0.5f, 2f))
        val max = TextToSpeech.getMaxSpeechInputLength() - 10
        val parts = clean.chunked(max)
        var ok = true
        parts.forEachIndexed { i, part ->
            val id = "sh${++counter}"
            if (i == parts.lastIndex) lastId = id
            val r = engine.speak(part, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, Bundle(), id)
            if (r != TextToSpeech.SUCCESS) ok = false
        }
        if (!ok) failed()
        return ok
    }

    fun stop() {
        hayai.stop()
        try { tts?.stop() } catch (_: Throwable) {}
        onSpeaking?.invoke(false)
    }

    fun shutdown() {
        try { tts?.stop(); tts?.shutdown() } catch (_: Throwable) {}
        tts = null
        _working.value = hayaiOk
    }

    /** Removes things that sound odd when read aloud: markdown marks, links, emoji. */
    private fun clean(text: String): String = text
        .replace(Regex("https?://\\S+"), " link ")
        .replace(Regex("[*_`#>~|]+"), " ")
        .replace(Regex("[\\p{So}\\p{Cs}]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}

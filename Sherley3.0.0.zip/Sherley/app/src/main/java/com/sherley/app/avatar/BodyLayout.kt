package com.sherley.app.avatar

import kotlin.math.hypot

/** Parts of her that react to touch. Only head, neck, shoulders and arms: nothing on the torso or legs. */
enum class Region { HEAD, NECK, SHOULDER_L, SHOULDER_R, UPPER_ARM_L, UPPER_ARM_R, ELBOW_L, ELBOW_R, FOREARM_L, FOREARM_R, HAND_L, HAND_R }

/** Joints you can long-press and reposition. (The library can pose the head and the arms only.) */
enum class Joint(val label: String, val region: Region) {
    NECK("neck", Region.NECK),
    SHOULDER_L("left shoulder", Region.SHOULDER_L),
    SHOULDER_R("right shoulder", Region.SHOULDER_R),
    ELBOW_L("left elbow", Region.ELBOW_L),
    ELBOW_R("right elbow", Region.ELBOW_R),
}

class Pt(val x: Float, val y: Float)

/** One touchable spot: a point or a line segment (a limb) with a radius, in pixels. */
internal class Spot(val region: Region, val a: Pt, val b: Pt?, val radius: Float) {
    /** < 1 means "inside", smaller = closer relative to its size. */
    fun score(p: Pt): Float {
        val d = if (b == null) hypot(p.x - a.x, p.y - a.y) else distToSegment(p, a, b)
        return d / radius
    }
}

private fun distToSegment(p: Pt, a: Pt, b: Pt): Float {
    val vx = b.x - a.x
    val vy = b.y - a.y
    val len2 = vx * vx + vy * vy
    val t = if (len2 < 1e-3f) 0f else (((p.x - a.x) * vx + (p.y - a.y) * vy) / len2).coerceIn(0f, 1f)
    return hypot(p.x - (a.x + t * vx), p.y - (a.y + t * vy))
}

/** Where each of her touchable parts is on the screen right now. */
class BodyLayout internal constructor(
    /** Named dots for the developer overlay. */
    val points: Map<String, Pt>,
    val heightPx: Float,
    private val spots: List<Spot>,
    private val pivots: Map<Joint, Pt>,
) {
    fun regionAt(p: Pt): Region? =
        spots.map { it to it.score(p) }.filter { it.second < 1f }.minByOrNull { it.second }?.first?.region

    /** The joint closest to a point, if any is near enough to count as pressed. */
    fun jointAt(p: Pt): Joint? =
        pivots.entries
            .map { it to hypot(p.x - it.value.x, p.y - it.value.y) / (heightPx * 0.07f).coerceAtLeast(30f) }
            .filter { it.second < 1f }
            .minByOrNull { it.second }?.first?.key

    fun pivot(j: Joint): Pt = pivots.getValue(j)
}

object BodyLayouts {

    // Proportions of a short little girl (about 6 heads tall), as fractions of her height from the feet:
    // a big head, a short neck, narrow low shoulders and short arms.
    private const val HEAD_Y = 0.905f
    private const val NECK_Y = 0.80f
    private const val SHOULDER_Y = 0.765f
    private const val SHOULDER_X = 0.095f
    private const val UPPER_ARM = 0.150f
    private const val FOREARM = 0.125f
    private const val HAND = 0.060f

    /**
     * Places her touchable parts on the screen from her feet, her height, her current pose and the camera.
     * With a [cal] (your joint calibration) the joint positions and arm lengths are the measured ones;
     * without it, typical human proportions are used.
     */
    fun compute(body: AvatarBody, pose: Pose, w: Float, h: Float, minRadius: Float, cal: JointCalibration?): BodyLayout? {
        val feet = body.feetWorld() ?: return null
        val top = body.headTopWorld() ?: return null
        val height = cal?.height ?: (top[1] - feet[1])
        if (height < 0.2f) return null

        // Positions as fractions of her height, measured from the feet (x sideways, y up).
        fun frac(key: String, defX: Float, defY: Float): FloatArray =
            cal?.pts?.get(key)?.let { floatArrayOf(it[0] / height, it[1] / height) } ?: floatArrayOf(defX, defY)

        val headF = frac("head", 0f, HEAD_Y)
        val neckF = frac("neck", 0f, NECK_Y)
        val shLF = frac("shL", SHOULDER_X, SHOULDER_Y)
        val shRF = frac("shR", -SHOULDER_X, SHOULDER_Y)
        // Limb lengths: measured if calibrated, otherwise typical proportions.
        fun len(aKey: String, bKey: String, default: Float): Float {
            val a = cal?.pts?.get(aKey)
            val b = cal?.pts?.get(bKey)
            return if (a != null && b != null) hypot(b[0] - a[0], b[1] - a[1]) / height else default
        }
        val upL = len("shL", "elL", UPPER_ARM)
        val upR = len("shR", "elR", UPPER_ARM)
        val loL = len("elL", "wrL", FOREARM)
        val loR = len("elR", "wrR", FOREARM)

        fun at(f: FloatArray) = floatArrayOf(feet[0] + f[0] * height, feet[1] + f[1] * height, feet[2])
        fun add(p: FloatArray, d: FloatArray, lenFrac: Float) =
            floatArrayOf(p[0] + d[0] * lenFrac * height, p[1] + d[1] * lenFrac * height, p[2] + d[2] * lenFrac * height)
        fun px(p: FloatArray): Pt? = body.project(p[0], p[1], p[2], w / h)?.let { Pt(it[0] * w, it[1] * h) }

        val f = px(feet) ?: return null
        val topPt = px(floatArrayOf(feet[0], feet[1] + height, feet[2])) ?: return null
        val hpx = hypot(f.x - topPt.x, f.y - topPt.y)
        if (hpx < 80f) return null
        fun r(frac: Float) = maxOf(frac * hpx, minRadius)

        val head = px(at(headF)) ?: return null
        val neck = px(at(neckF)) ?: return null
        val shL = at(shLF)
        val shR = at(shRF)
        val elL = add(shL, pose.lUpper, upL)
        val elR = add(shR, pose.rUpper, upR)
        val wrL = add(elL, pose.lLower, loL)
        val wrR = add(elR, pose.rLower, loR)
        val hdL = add(wrL, pose.lLower, HAND)
        val hdR = add(wrR, pose.rLower, HAND)

        val pShL = px(shL) ?: return null
        val pShR = px(shR) ?: return null
        val pElL = px(elL) ?: return null
        val pElR = px(elR) ?: return null
        val pWrL = px(wrL) ?: return null
        val pWrR = px(wrR) ?: return null
        val pHdL = px(hdL) ?: return null
        val pHdR = px(hdR) ?: return null

        val spots = listOf(
            Spot(Region.HEAD, head, null, r(0.10f)),
            Spot(Region.NECK, neck, null, r(0.04f)),
            Spot(Region.SHOULDER_L, pShL, null, r(0.05f)),
            Spot(Region.SHOULDER_R, pShR, null, r(0.05f)),
            Spot(Region.UPPER_ARM_L, pShL, pElL, r(0.04f)),
            Spot(Region.UPPER_ARM_R, pShR, pElR, r(0.04f)),
            Spot(Region.ELBOW_L, pElL, null, r(0.045f)),
            Spot(Region.ELBOW_R, pElR, null, r(0.045f)),
            Spot(Region.FOREARM_L, pElL, pWrL, r(0.04f)),
            Spot(Region.FOREARM_R, pElR, pWrR, r(0.04f)),
            Spot(Region.HAND_L, pWrL, pHdL, r(0.05f)),
            Spot(Region.HAND_R, pWrR, pHdR, r(0.05f)),
        )
        val pivots = mapOf(
            Joint.NECK to neck,
            Joint.SHOULDER_L to pShL, Joint.SHOULDER_R to pShR,
            Joint.ELBOW_L to pElL, Joint.ELBOW_R to pElR,
        )
        val dots = mapOf(
            "top" to topPt, "head" to head, "neck" to neck, "shL" to pShL, "shR" to pShR,
            "elL" to pElL, "elR" to pElR, "wrL" to pWrL, "wrR" to pWrR, "hdL" to pHdL, "hdR" to pHdR,
        )
        return BodyLayout(dots, hpx, spots, pivots)
    }

    /**
     * Turns a finger position into the direction a joint should point.
     * Dragging around a shoulder aims the upper arm, around an elbow the forearm, around the neck the head.
     */
    fun aim(body: AvatarBody, joint: Joint, layout: BodyLayout, finger: Pt): FloatArray? {
        val basis = body.cameraBasis() ?: return null
        val pivot = layout.pivot(joint)
        val dx = finger.x - pivot.x
        val dy = pivot.y - finger.y // screen y grows downward
        val toward = if (joint == Joint.NECK) layout.heightPx * 0.35f else hypot(dx, dy) * 0.25f + 1f
        return V.norm(
            basis.right[0] * dx + basis.up[0] * dy + basis.toViewer[0] * toward,
            basis.right[1] * dx + basis.up[1] * dy + basis.toViewer[1] * toward,
            basis.right[2] * dx + basis.up[2] * dy + basis.toViewer[2] * toward,
        )
    }
}

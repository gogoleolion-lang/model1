package com.sherley.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.sherley.app.ui.SherleyApp
import com.sherley.app.ui.theme.SherleyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.sherley.app.config.CrashInfo.install(this)
        enableEdgeToEdge()
        setContent {
            SherleyTheme {
                SherleyApp()
            }
        }
    }
}

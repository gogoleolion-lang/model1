package com.sherley.app.config

/**
 * Every tunable number and default in one place.
 * Edit here first when you want to change how Sherley behaves.
 */
object AppConfig {

    // ---- Character -------------------------------------------------------
    const val COMPANION_NAME = "Sherlock Holmes"
    const val NICKNAME = "Sherley"
    const val DEFAULT_USER_NAME = "Al-Haitham"

    // ---- Chat: language model running in the Thinai app on this phone ---------
    /** Thinai's local server (OpenAI-style /v1 routes). */
    const val DEFAULT_LOCAL_URL = "http://127.0.0.1:11434"

    /**
     * Cap on one reply, including the small JSON wrapper (mood tags, facts). On a phone every token
     * costs seconds, so keep it modest. Raise it if replies get cut off.
     */
    const val CHAT_MAX_OUTPUT_TOKENS = 600
    const val CHAT_TEMPERATURE = 0.8

    // ---- Memory ------------------------------------------------------------
    /** How many recent back-and-forth turns are sent with every request. */
    const val DEFAULT_HISTORY_TURNS = 8

    /** When this many messages are not yet summarized, older ones get folded into the summary. */
    const val SUMMARY_TRIGGER_MESSAGES = 40
    const val SUMMARY_BATCH_MESSAGES = 24

    const val MAX_FACTS_IN_PROMPT = 6
    const val MAX_FACTS_STORED = 300

    // ---- UI ----------------------------------------------------------------
    /** A reply taller than this fraction of the screen becomes a clue icon. */
    const val LONG_REPLY_VIEWPORT_FRACTION = 0.5f

    /** 0 = fully transparent input box, 1 = solid black. */
    const val INPUT_BG_ALPHA = 0.12f

    // ---- Body and touch ------------------------------------------------------
    /** This many taps within the window below count as "poke spam". */
    const val POKE_SPAM_COUNT = 5
    const val POKE_SPAM_WINDOW_MS = 6_000L

    /** A drag must travel at least this fraction of the screen width to count as a head pat. */
    const val STROKE_MIN_FRACTION = 0.12f

    /** How long an instant (no language model) reaction stays in her speech bubble. */
    const val REFLEX_SHOW_MS = 8_000L

    /** Quiet time before she may say something on her own, and how long a touch stays "recent" for chat. */
    const val IDLE_BARK_AFTER_MS = 90_000L
    const val TOUCH_NOTE_VALID_MS = 3 * 60_000L
}

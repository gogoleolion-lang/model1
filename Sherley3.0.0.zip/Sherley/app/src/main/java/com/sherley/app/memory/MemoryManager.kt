package com.sherley.app.memory

import com.sherley.app.ai.LocalLlmClient
import com.sherley.app.config.AppConfig
import com.sherley.app.config.AppSettings
import com.sherley.app.data.ChatDao
import com.sherley.app.data.FactEntity

/**
 * Sherley's long-term memory. Two layers keep the prompt short, which matters a lot for a small
 * on-device model (long prompts are slow and fill its context window):
 *
 *  1. Facts   - short lasting things about you. Only the few most relevant to your current
 *               message are sent with a request (relevantFacts).
 *  2. Summary - when the unsummarized history grows, the oldest batch is condensed into one
 *               short rolling summary (maybeSummarize). The full history stays on the phone.
 */
class MemoryManager(
    private val dao: ChatDao,
    private val settings: AppSettings,
    private val llm: LocalLlmClient,
) {

    fun summary(): String = settings.summaryText

    // ---- Facts -------------------------------------------------------------
    suspend fun addFacts(newFacts: List<String>) {
        if (newFacts.isEmpty()) return
        val existing = dao.allFacts()
        if (existing.size >= AppConfig.MAX_FACTS_STORED) return
        val known = existing.map { normalize(it.text) }.toMutableList()

        for (raw in newFacts) {
            val text = raw.trim().take(160)
            val norm = normalize(text)
            if (norm.isBlank()) continue
            if (known.any { it == norm || it.contains(norm) || norm.contains(it) }) continue
            dao.insertFact(FactEntity(text = text, createdAt = System.currentTimeMillis()))
            known += norm
        }
    }

    /** The facts that share the most words with the message, plus a nudge toward recent ones. */
    suspend fun relevantFacts(message: String): List<String> {
        val facts = dao.allFacts()
        if (facts.isEmpty()) return emptyList()

        val words = tokens(message)
        val scored = facts.mapIndexed { index, fact ->
            val overlap = tokens(fact.text).count { it in words }
            val recency = index.toFloat() / facts.size // 0 (oldest) .. ~1 (newest)
            fact.text to (overlap * 2f + recency)
        }
        return scored
            .sortedByDescending { it.second }
            .take(AppConfig.MAX_FACTS_IN_PROMPT)
            .map { it.first }
    }

    // ---- Rolling summary -----------------------------------------------------
    suspend fun maybeSummarize() {
        val afterId = settings.summarizedUpToId
        if (dao.countAfter(afterId) <= AppConfig.SUMMARY_TRIGGER_MESSAGES) return

        val batch = dao.after(afterId, AppConfig.SUMMARY_BATCH_MESSAGES)
        if (batch.isEmpty()) return

        val user = settings.userName
        val transcript = batch.joinToString("\n") {
            val who = if (it.role == "user") user else AppConfig.NICKNAME
            "$who: ${it.text.take(500)}"
        }
        val prompt = """
Update a running summary of a friendship between $user and ${AppConfig.NICKNAME}, a witty 12-year-old detective companion.

Current summary:
${settings.summaryText.ifBlank { "(none yet)" }}

New messages to fold in:
$transcript

Write the updated summary in under 180 words. Keep lasting facts, ongoing topics, running jokes, and unresolved questions. Drop small talk. Output only the summary.
""".trimIndent()

        val updated = llm.plainText(prompt).trim()
        if (updated.isNotBlank()) {
            settings.summaryText = updated
            settings.summarizedUpToId = batch.last().id
        }
    }

    suspend fun clearAll() {
        dao.clearMessages()
        dao.clearFacts()
        settings.summaryText = ""
        settings.summarizedUpToId = 0L
    }

    // ---- helpers -------------------------------------------------------------
    private val wordRegex = Regex("[a-z0-9']+")
    private val stopWords = setOf(
        "the", "and", "for", "that", "with", "this", "you", "are", "was", "have", "has", "his",
        "her", "its", "they", "them", "from", "about", "into", "likes", "like", "what", "when",
    )

    private fun tokens(text: String): Set<String> =
        wordRegex.findAll(text.lowercase()).map { it.value }
            .filter { it.length > 2 && it !in stopWords }
            .toSet()

    private fun normalize(text: String): String =
        text.lowercase().filter { it.isLetterOrDigit() || it == ' ' }.trim()
}

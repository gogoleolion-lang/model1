package com.sherley.app.imports

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

/**
 * Makes an arbitrary room model fit the app: guesses its size unit (metres / centimetres / millimetres),
 * scales it to match her size, and works out where the floor is, the walkable area and where she starts.
 * The built-in rooms follow the same convention: floor at y = -1, room centred at z = -4, 1 metre = 1.18 units.
 */
object RoomFit {
    private const val UNITS_PER_METRE = 1.18f

    class Fitted(val glb: ByteArray, val meta: JSONObject, val widthMetres: Float, val depthMetres: Float, val heightMetres: Float)

    fun fit(glbBytes: ByteArray): Fitted {
        val g = Glb.parse(glbBytes)
        val json = g.json
        val accessors = json.optJSONArray("accessors") ?: JSONArray()
        val nodes = json.optJSONArray("nodes") ?: JSONArray()
        val meshes = json.optJSONArray("meshes") ?: JSONArray()
        val roots = json.optJSONArray("scenes")?.optJSONObject(json.optInt("scene", 0))?.optJSONArray("nodes")
            ?: JSONArray().also { for (i in 0 until nodes.length()) it.put(i) }

        val mn = floatArrayOf(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE)
        val mx = floatArrayOf(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)

        fun visit(i: Int, parent: FloatArray, depth: Int) {
            if (depth > 64 || i !in 0 until nodes.length()) return
            val n = nodes.getJSONObject(i)
            val world = mulMat(parent, local(n))
            if (n.has("mesh")) {
                val mesh = meshes.optJSONObject(n.getInt("mesh"))
                val prims = mesh?.optJSONArray("primitives")
                if (prims != null) for (k in 0 until prims.length()) {
                    val pos = prims.getJSONObject(k).optJSONObject("attributes")?.optInt("POSITION", -1) ?: -1
                    val a = accessors.optJSONObject(pos) ?: continue
                    val amin = a.optJSONArray("min") ?: continue
                    val amax = a.optJSONArray("max") ?: continue
                    for (c in 0 until 8) {
                        val p = floatArrayOf(
                            (if (c and 1 == 0) amin.getDouble(0) else amax.getDouble(0)).toFloat(),
                            (if (c and 2 == 0) amin.getDouble(1) else amax.getDouble(1)).toFloat(),
                            (if (c and 4 == 0) amin.getDouble(2) else amax.getDouble(2)).toFloat(),
                        )
                        val w = transform(world, p)
                        for (d in 0..2) { mn[d] = min(mn[d], w[d]); mx[d] = max(mx[d], w[d]) }
                    }
                }
            }
            val ch = n.optJSONArray("children")
            if (ch != null) for (k in 0 until ch.length()) visit(ch.getInt(k), world, depth + 1)
        }
        for (r in 0 until roots.length()) visit(roots.getInt(r), IDENTITY, 0)
        require(mn[0] <= mx[0]) { "Could not measure this model (no meshes with sizes)." }

        val ex = mx[0] - mn[0]; val ey = mx[1] - mn[1]; val ez = mx[2] - mn[2]
        val longest = max(ex, ez)
        // Guess the unit from the size: rooms are 2-30 m; if it looks hundreds of units wide it is probably centimetres.
        val toMetres = when {
            longest <= 60f -> 1f
            longest <= 6000f -> 0.01f
            else -> 0.001f
        }
        val s = toMetres * UNITS_PER_METRE
        val cx = (mn[0] + mx[0]) / 2f * s; val cz = (mn[2] + mx[2]) / 2f * s
        val floorY = mn[1] * s

        // Wrap the model in a new root node that applies the scale.
        val newRoot = JSONObject().put("name", "SherleyRoomRoot").put("scale", JSONArray(listOf(s.toDouble(), s.toDouble(), s.toDouble())))
            .put("children", roots)
        nodes.put(newRoot)
        val sceneIdx = json.optInt("scene", 0)
        val scenes = json.optJSONArray("scenes") ?: JSONArray().put(JSONObject()).also { json.put("scenes", it) }
        scenes.getJSONObject(sceneIdx).put("nodes", JSONArray().put(nodes.length() - 1))
        json.put("nodes", nodes)
        json.put("scene", sceneIdx)

        val wM = ex * toMetres; val dM = ez * toMetres; val hM = ey * toMetres
        val halfX = min(wM * UNITS_PER_METRE / 2f - 0.4f, 9f).coerceAtLeast(0.6f)
        val halfZ = min(dM * UNITS_PER_METRE / 2f - 0.4f, 9f).coerceAtLeast(0.6f)
        val meta = JSONObject()
            .put("offsetX", (-cx).toDouble()).put("offsetY", (-1f - floorY).toDouble()).put("offsetZ", (-4f - cz).toDouble())
            .put("yawDeg", 0)
            .put("bounds", JSONObject().put("minX", -halfX.toDouble()).put("maxX", halfX.toDouble())
                .put("minZ", (-4f - halfZ).toDouble()).put("maxZ", (-4f + halfZ).toDouble()))
            .put("spawn", JSONObject().put("x", 0.0).put("y", -0.97).put("z", -4.0).put("yawDeg", 0))
        return Fitted(Glb.write(json, g.bin), meta, wM, dM, hM)
    }

    // ---- small 4x4 matrix helpers (column-major, like glTF) ----
    private val IDENTITY = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)

    private fun local(n: JSONObject): FloatArray {
        n.optJSONArray("matrix")?.let { a -> if (a.length() == 16) return FloatArray(16) { a.getDouble(it).toFloat() } }
        val t = n.optJSONArray("translation"); val r = n.optJSONArray("rotation"); val sc = n.optJSONArray("scale")
        val tx = t?.getDouble(0)?.toFloat() ?: 0f; val ty = t?.getDouble(1)?.toFloat() ?: 0f; val tz = t?.getDouble(2)?.toFloat() ?: 0f
        val qx = r?.getDouble(0)?.toFloat() ?: 0f; val qy = r?.getDouble(1)?.toFloat() ?: 0f; val qz = r?.getDouble(2)?.toFloat() ?: 0f; val qw = r?.getDouble(3)?.toFloat() ?: 1f
        val sx = sc?.getDouble(0)?.toFloat() ?: 1f; val sy = sc?.getDouble(1)?.toFloat() ?: 1f; val sz = sc?.getDouble(2)?.toFloat() ?: 1f
        return floatArrayOf(
            (1 - 2 * (qy * qy + qz * qz)) * sx, (2 * (qx * qy + qz * qw)) * sx, (2 * (qx * qz - qy * qw)) * sx, 0f,
            (2 * (qx * qy - qz * qw)) * sy, (1 - 2 * (qx * qx + qz * qz)) * sy, (2 * (qy * qz + qx * qw)) * sy, 0f,
            (2 * (qx * qz + qy * qw)) * sz, (2 * (qy * qz - qx * qw)) * sz, (1 - 2 * (qx * qx + qy * qy)) * sz, 0f,
            tx, ty, tz, 1f,
        )
    }

    private fun mulMat(a: FloatArray, b: FloatArray): FloatArray {
        val o = FloatArray(16)
        for (c in 0..3) for (r in 0..3) {
            var s = 0f
            for (k in 0..3) s += a[k * 4 + r] * b[c * 4 + k]
            o[c * 4 + r] = s
        }
        return o
    }

    private fun transform(m: FloatArray, p: FloatArray) = floatArrayOf(
        m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12],
        m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13],
        m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14],
    )
}

package com.sherley.app.companion

import java.util.Calendar
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * The heart of Sherley's personality. Pure functions: state in, new state out.
 *
 * How a mood is born:
 *  1. tick()        - time passes: energy follows the day, silence drains Company, puzzles
 *                     go stale, old event boosts fade, and tiny random drift keeps her alive.
 *  2. applyEvents() - your message happened: needs change, boosts push certain moods.
 *  3. pickMood()    - every mood gets a score from the needs (baseScore) + boosts + inertia;
 *                     the highest wins. Intensity is how strongly it won.
 *
 * To tune her personality, change the numbers in baseScore() and in ChatEvent.
 */
object MoodEngine {

    private const val HOUR_MS = 3_600_000f

    /** Bonus for staying in the current mood, so moods linger instead of flickering. */
    private const val INERTIA = 0.12f

    /** Random wobble added to every score, so equal-ish moods do not always resolve the same way. */
    private const val NOISE = 0.08f

    /** How strongly recent events (compliment, insult, puzzle...) push toward their moods. */
    private const val BOOST_WEIGHT = 1.4f

    // ---------------------------------------------------------------------
    // 1. Time passing
    // ---------------------------------------------------------------------
    fun tick(state: MoodState, now: Long, random: Random = Random.Default): MoodState {
        val hours = ((now - state.lastTickAt) / HOUR_MS).coerceIn(0f, 48f)
        if (hours < 0.005f) return state // under ~18 seconds: nothing to do

        val n = state.needs
        val idleHours = ((now - state.lastMessageAt) / HOUR_MS).coerceAtLeast(0f)
        val hour = hourOfDay(now)
        val pull = (hours * 0.35f).coerceAtMost(1f)   // how fast energy chases its daily target
        val drift = (hours * 0.10f).coerceAtMost(1f)  // how fast soft needs return to normal
        val wobble = sqrt(hours)
        fun jitter(amount: Float) = (random.nextFloat() * 2f - 1f) * amount * wobble

        val needs = Needs(
            energy = Needs.clamp(n.energy + (circadianEnergy(hour) - n.energy) * pull + jitter(2f)),
            stimulation = Needs.clamp(n.stimulation - 3f * hours + jitter(2f)),
            company = Needs.clamp(n.company - (if (idleHours > 1f) 4f * hours else 0f) + jitter(1f)),
            respect = Needs.clamp(n.respect + (65f - n.respect) * drift + jitter(1.5f)),
            comfort = Needs.clamp(n.comfort + (65f - n.comfort) * drift + jitter(1.5f)),
            confidence = Needs.clamp(n.confidence + (65f - n.confidence) * drift + jitter(1.5f)),
        )

        // Event boosts have a one-hour half-life.
        val fade = 0.5f.pow(hours)
        val boosts = state.boosts
            .mapValues { it.value * fade }
            .filterValues { it >= 0.05f }

        return pickMood(state.copy(needs = needs, boosts = boosts, lastTickAt = now), now, random)
    }

    // ---------------------------------------------------------------------
    // 2. Something happened in the chat
    // ---------------------------------------------------------------------
    fun applyEvents(
        state: MoodState,
        events: List<ChatEvent>,
        now: Long,
        random: Random = Random.Default,
        companyBoost: Float = 8f,
        extraNeeds: NeedsDelta? = null,
        extraBoosts: Map<Mood, Float> = emptyMap(),
    ): MoodState {
        // Simply being talked to fills Company a little (touches fill a bit less).
        var needs = state.needs + NeedsDelta(company = companyBoost)

        // Older boosts fade a bit with every message, then the new ones are added.
        val boosts = state.boosts.mapValues { it.value * 0.6f }.toMutableMap()

        for (event in events.distinct()) {
            needs += event.needs
            for ((mood, amount) in event.boosts) {
                boosts[mood] = ((boosts[mood] ?: 0f) + amount).coerceAtMost(1f)
            }
        }

        // Touch reactions bring their own need changes and mood pushes.
        if (extraNeeds != null) needs += extraNeeds
        for ((mood, amount) in extraBoosts) boosts[mood] = ((boosts[mood] ?: 0f) + amount).coerceAtMost(1f)

        return pickMood(
            state.copy(
                needs = needs,
                boosts = boosts.filterValues { it >= 0.05f },
                lastMessageAt = now,
                lastTickAt = now,
            ),
            now,
            random,
        )
    }

    // ---------------------------------------------------------------------
    // 3. Choosing the mood
    // ---------------------------------------------------------------------
    fun pickMood(state: MoodState, now: Long, random: Random = Random.Default): MoodState {
        val hour = hourOfDay(now)
        var best = state.mood
        var bestScore = -1f

        for (mood in Mood.values()) {
            var score = baseScore(mood, state.needs, hour)
            score += (state.boosts[mood] ?: 0f) * BOOST_WEIGHT
            if (mood == state.mood) score += INERTIA
            score += random.nextFloat() * NOISE
            if (score > bestScore) {
                best = mood
                bestScore = score
            }
        }

        val intensity = ((bestScore - 0.15f) / 0.85f).coerceIn(0.2f, 1f)
        return state.copy(mood = best, intensity = intensity)
    }

    /** 0..1 how low a need is (1 = empty). */
    private fun low(x: Float) = ((50f - x) / 50f).coerceIn(0f, 1f)

    /** 0..1 how high a need is (1 = full). */
    private fun high(x: Float) = ((x - 50f) / 50f).coerceIn(0f, 1f)

    private fun isNight(hour: Int) = hour >= 22 || hour < 6
    private fun isMorning(hour: Int) = hour in 6..11

    /**
     * The personality table: how much each mood "wants" to happen given the needs and the hour.
     * Read each line as: base + weights * how low/high a need is. Tweak freely.
     */
    private fun baseScore(m: Mood, n: Needs, hour: Int): Float {
        val night = if (isNight(hour)) 1f else 0f
        val morning = if (isMorning(hour)) 1f else 0f
        return when (m) {
            // Joy
            Mood.HAPPY -> 0.20f + 0.35f * high(n.company) + 0.25f * high(n.comfort)
            Mood.CHEERFUL -> 0.15f + 0.30f * high(n.energy) + 0.25f * high(n.comfort) + 0.10f * morning
            Mood.DELIGHTED -> 0.10f + 0.30f * high(n.respect) + 0.30f * high(n.stimulation) + 0.20f * high(n.company)
            Mood.PLAYFUL -> 0.10f + 0.30f * high(n.energy) + 0.30f * high(n.comfort) + 0.20f * high(n.stimulation)
            Mood.PROUD -> 0.05f + 0.50f * high(n.confidence) + 0.30f * high(n.respect)
            Mood.GIDDY -> 0.50f * minOf(high(n.energy), high(n.stimulation)) + 0.20f * high(n.company)

            // Energy
            Mood.EXCITED -> 0.50f * high(n.stimulation) + 0.30f * high(n.energy)
            Mood.EAGER -> 0.10f + 0.30f * high(n.stimulation) + 0.20f * high(n.energy) + 0.10f * high(n.confidence)
            Mood.MISCHIEVOUS -> 0.05f + 0.30f * high(n.energy) + 0.25f * high(n.confidence) + 0.20f * high(n.comfort)
            Mood.COCKY -> 0.50f * high(n.confidence) + 0.30f * high(n.respect) - 0.20f * low(n.comfort)
            Mood.HYPER -> 0.60f * minOf(high(n.energy), high(n.company)) + 0.20f * morning

            // Focus
            Mood.CURIOUS -> 0.20f + 0.30f * high(n.stimulation) + 0.20f * high(n.energy)
            Mood.INTRIGUED -> 0.05f + 0.20f * high(n.stimulation)
            Mood.SCHEMING -> 0.05f + 0.20f * high(n.confidence) + 0.20f * high(n.stimulation)
            Mood.THOUGHTFUL -> 0.15f + 0.20f * high(n.comfort) + 0.20f * low(n.energy) + 0.10f * night
            Mood.SUSPICIOUS -> 0.20f * low(n.comfort)
            Mood.DETERMINED -> 0.30f * high(n.confidence) + 0.20f * high(n.energy)

            // Calm
            Mood.RELAXED -> 0.15f + 0.35f * high(n.comfort) - 0.20f * high(n.energy)
            Mood.CONTENT -> 0.20f + 0.25f * high(n.comfort) + 0.20f * high(n.company) + 0.10f * high(n.respect)
            Mood.COZY -> 0.25f * night + 0.30f * high(n.comfort) + 0.20f * low(n.energy)
            Mood.DREAMY -> 0.30f * minOf(low(n.stimulation), high(n.comfort)) + 0.10f * night
            Mood.NOSTALGIC -> 0.05f + 0.20f * low(n.stimulation) + 0.05f * night

            // Low energy
            Mood.BORED -> 0.80f * low(n.stimulation)
            Mood.SLEEPY -> 0.90f * low(n.energy) + 0.25f * night
            Mood.LAZY -> 0.40f * low(n.energy) + 0.30f * low(n.stimulation) + 0.20f * high(n.comfort)
            Mood.TIRED -> 0.70f * low(n.energy)
            Mood.DISTRACTED -> 0.30f * low(n.stimulation) + 0.20f * low(n.comfort)

            // Sadness
            Mood.SAD -> 0.60f * low(n.comfort) + 0.20f * low(n.confidence)
            Mood.LONELY -> 0.80f * low(n.company)
            Mood.DISAPPOINTED -> 0.40f * low(n.confidence) + 0.30f * low(n.respect)
            Mood.HOMESICK -> 0.25f * low(n.company) * night
            Mood.SULKY -> 0.60f * low(n.respect) + 0.20f * low(n.comfort)

            // Irritation
            Mood.ANNOYED -> 0.50f * low(n.respect) + 0.30f * low(n.comfort)
            Mood.GRUMPY -> 0.40f * low(n.energy) + 0.30f * low(n.respect) + 0.20f * low(n.comfort)
            Mood.JEALOUS -> 0f // only appears through event boosts
            Mood.FRUSTRATED -> 0.40f * low(n.confidence) + 0.30f * low(n.comfort)
            Mood.STUBBORN -> 0.30f * low(n.respect) + 0.20f * high(n.confidence)

            // Social / emotional
            Mood.EMBARRASSED -> 0f // only appears through event boosts
            Mood.SHY -> 0.20f * low(n.confidence)
            Mood.WORRIED -> 0.50f * low(n.comfort) + 0.10f * high(n.company)
            Mood.NERVOUS -> 0.30f * low(n.confidence) + 0.30f * low(n.comfort)
            Mood.AFFECTIONATE -> 0.05f + 0.20f * high(n.company) + 0.30f * high(n.comfort) + 0.20f * high(n.respect)
            Mood.SASSY -> 0.10f + 0.30f * high(n.confidence) + 0.20f * high(n.energy) + 0.10f * high(n.respect)
        }
    }

    // ---------------------------------------------------------------------
    // Daily rhythm
    // ---------------------------------------------------------------------
    /** Target energy for each hour of the (local) day: lively mornings, a dip after lunch, sleepy nights. */
    private fun circadianEnergy(hour: Int): Float = when (hour) {
        in 6..8 -> 60f
        in 9..12 -> 85f
        in 13..15 -> 65f
        in 16..19 -> 75f
        in 20..21 -> 55f
        else -> 25f // 22:00 to 05:59
    }

    private fun hourOfDay(now: Long): Int =
        Calendar.getInstance().apply { timeInMillis = now }.get(Calendar.HOUR_OF_DAY)
}

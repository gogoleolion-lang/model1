package com.neethu.corelib

/**
 * Preset camera shots for framing the avatar, applied with a smooth
 * transition (see [AvatarController.setCameraShot]).
 *
 * Framing is derived from the model's humanoid bones at call time — the
 * Close-Up look-at tracks the head, the other shots track the chest/hips —
 * so every model (and any animation pose) is framed correctly.
 *
 * @property label Human-readable label (Chinese), usable directly in UI.
 * @property labelEn English label for English-mode UI and prompts.
 */
enum class CameraShot(val label: String, val labelEn: String) {

    /**
     * 面部特写 — chest-up to head (bust shot). The look-at point is bound
     * to the model's head bone.
     */
    CLOSE_UP("面部特写 CU", "Close-Up CU"),

    /**
     * 面部微距 — tighter than CLOSE_UP: the pivot stays on the face and the
     * camera dollies to ~0.6× of the close-up distance, so the face fills
     * the frame. Exposed to the LLM as `<cam:macro>`.
     */
    MACRO("面部微距 MC", "Face Macro MC"),

    /**
     * 中景半身 — waist-up to head, the standard streamer framing.
     * Look-at is bound between head and hips.
     */
    MEDIUM_SHOT("中景半身 MS", "Medium Shot MS"),

    /**
     * 全景全身 — head to feet with some ground below.
     * Look-at is bound around the hips (body center).
     */
    FULL_SHOT("全景全身 FS", "Full Shot FS"),

    /**
     * 远景 — the full-body shot pulled further back, leaving margin above
     * the head and below the feet so large dance movements stay in frame.
     * Look-at is bound to the hips (body center).
     */
    LONG_SHOT("远景 LS", "Long Shot LS"),

    /**
     * 反应侧景 — half-body view from ~38° to the side-front, as if seen
     * over a conversation partner's shoulder.
     */
    OVER_SHOULDER("反应侧景 OS", "Over-Shoulder OS"),

    /**
     * 跟拍 — walking companion framing: the pivot rides the moving body
     * (hips-weighted anchor) and the steering never "arrives", so the closed
     * loop keeps tracking while the avatar walks. Yaw/pitch preserve the
     * camera's current angle at activation. Intended for locomotion
     * (`<cam:follow>`); while standing still it behaves like a slightly
     * wider full shot.
     */
    FOLLOW("跟拍 FL", "Follow FL"),

    /**
     * 双人同框（多虚拟人 P3）— group two-shot: the pivot is the midpoint of
     * all cast head anchors and the distance scales with the head-to-head
     * span, so 2~3 avatars in conversation stay framed as they move. Like
     * FOLLOW the steering never arrives (tracking shot), but unlike FOLLOW
     * the yaw/pitch are fixed constants — pose derives only from world bone
     * anchors, never from camera state (坑 22 自参照固化的多目标版纪律).
     */
    GROUP_SHOT("双人同框 GS", "Group Shot GS");

    /** Language-aware label for UI badges and prompt lines. */
    fun label(lang: Lang): String = if (lang == Lang.EN) labelEn else label
}

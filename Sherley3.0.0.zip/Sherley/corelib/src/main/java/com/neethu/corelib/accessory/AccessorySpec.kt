package com.neethu.corelib.accessory

/**
 * 配饰来源（对齐 AvatarSpec 的 assets/文件双通道惯例）。
 */
sealed interface AccessorySource {
    /** assets/ 相对路径（内置资产，如 `accessories/phone.glb`）。 */
    data class Asset(val path: String) : AccessorySource

    /** 文件系统绝对路径（SAF 导入等外置资产）。 */
    data class File(val path: String) : AccessorySource
}

/**
 * 世界坐标挂载点（P1 道具系统 §6.2 地面/场景道具）：瑜伽垫铺地上、茶具摆
 * 桌上——不挂骨骼，按 SDK 世界坐标摆放（与交互点表/走动同坐标系，米制，
 * yawDeg 0=+Z 同 `InteractionAnchor` 约定）。坐标通常来自活动配方里的
 * 场景锚点（`{"mount":"world","anchor":"yoga_spot"}`），由编排层解析注入。
 */
data class AccessoryWorldMount(
    val x: Float,
    val y: Float,
    val z: Float,
    val yawDeg: Float = 0f,
)

/**
 * 配饰挂载规格（docs/accessory-feasibility.md §5.5 P0 子集）。
 *
 * 单位约定：[position]/[rotationEulerYXZ] 为**目标骨骼局部系**的偏移，
 * 模型单位（VRM = 米、角度 = 度）。avatar 根上的 unit-cube 归一缩放经
 * 父链自动传播到配饰，因此这里不再做 renderScale 换算（§5.3 公式按
 * 「父链已带根缩放」修正——调研期公式的双重缩放在 P0 真机标定中证伪）；
 * [scale] 只承担逐资产校准系数（修正资产建模偏差）。
 *
 * [world] 非 null = 世界坐标挂载（§6.2）：不解析骨骼、不 setParent（无父
 * 即世界系），TRS = `T(锚点)·Ry(yaw)·局部TRS`，此时 [position]/
 * [rotationEulerYXZ]/[scale] 语义变为**锚点之上的局部微调**（校准同链），
 * [bone] 不参与（观测面报 `world`）。
 *
 * FloatArray 字段按内容判等（data class 默认引用等对数组不适用）。
 */
data class AccessorySpec(
    /** 配饰 ID（同一演员内唯一；重复 attach 返回失败）。 */
    val id: String,
    val source: AccessorySource,
    /** 语义骨骼名：`rightHand`/`head`/`chest`…（VRM humanoid map 语义）。 */
    val bone: String,
    /** 世界坐标挂载点（§6.2）；null = 既有骨骼挂载。 */
    val world: AccessoryWorldMount? = null,
    /** 骨骼局部系平移偏移（模型单位）。 */
    val position: FloatArray = FloatArray(3),
    /** 骨骼局部系旋转，YXZ 内在欧拉（度）。 */
    val rotationEulerYXZ: FloatArray = FloatArray(3),
    /** 逐资产校准系数（1 = 资产按真实米制建模）。 */
    val scale: Float = 1f,
    /** 阴影默认关（SPOT 阴影 + PCSS 在 Adreno 有真机悬崖）。 */
    val castShadows: Boolean = false,
    /**
     * 弹簧骨骼外部碰撞体半径（米，骨骼局部系；P2-3 帽子压头发实验，
     * docs/accessory-feasibility.md §5.6）。>0 = 挂载时在 [bone] 上注册
     * 一个球碰撞体（球心 = [position] 偏移），头发链被推出配饰外；卸载
     * 时注销。0 = 关（默认，头手道具无头发穿插问题）。
     */
    val springColliderRadius: Float = 0f,
) {
    override fun equals(other: Any?): Boolean =
        other is AccessorySpec &&
            id == other.id && source == other.source && bone == other.bone &&
            world == other.world &&
            position.contentEquals(other.position) &&
            rotationEulerYXZ.contentEquals(other.rotationEulerYXZ) &&
            scale == other.scale && castShadows == other.castShadows &&
            springColliderRadius == other.springColliderRadius

    override fun hashCode(): Int =
        arrayOf(id, source, bone, world, scale, castShadows, springColliderRadius).contentHashCode()
}

/** 已挂载配饰的观测快照（调试命令 / LLM 观测用）。 */
data class AccessoryState(
    val id: String,
    val bone: String,
    val visible: Boolean,
)

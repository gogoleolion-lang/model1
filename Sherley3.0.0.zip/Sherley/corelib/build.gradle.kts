plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// The avatar renderer, bundled as source (from the AIAvatar-SDK repository, Apache-2.0)
// because the published 0.1.5 release is older than the 3D room / walking / sitting features.
android {
    namespace = "com.neethu.corelib"
    compileSdk = 36

    defaultConfig {
        minSdk = 29
        consumerProguardFiles("consumer-rules.pro")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    api("androidx.lifecycle:lifecycle-runtime-ktx:2.8.5")
    api("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.1")

    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    api("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")

    implementation("com.google.android.filament:filament-android:1.68.3")
    implementation("com.google.android.filament:gltfio-android:1.68.3")
    implementation("com.google.android.filament:filament-utils-android:1.68.3")
    implementation("com.google.android.filament:filamat-android:1.68.3")

    implementation("com.google.code.gson:gson:2.10.1")
}

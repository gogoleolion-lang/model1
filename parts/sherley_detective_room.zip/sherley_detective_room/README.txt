Sherley - The Detective's Room (private package for the Sherley app)
Built from the VR.Space Furniture Asset Pack 2022, the haru Coffee Set and Punisher Zenith by Trista.
All are licensed assets: do not share or re-upload this zip.
Install: Sherley > Settings > Sherley Environment System > The Detective's Room > Choose the zip from the phone.
